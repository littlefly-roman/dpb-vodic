# DPB Driver Dashboard – štruktúra projektu (krok 1)

Spúšťanie: otvor priečinok vo VS Code a spusti **Live Server** na `dpb_app_v11.html`
(dvojklik na súbor nefunguje, appka načítava grafikon cez `fetch`).

## Kde čo je

| Priečinok / súbor | Čo obsahuje |
|---|---|
| `dpb_app_v11.html` | tenká stránka: značky obrazoviek + zoznam načítaných skriptov |
| `style.css` | štýly vrátane nočného režimu |
| `js/core/` | `kalendar.js` (typy dní, sviatky, výber priečinka grafikonu), `cas.js` (dátum a čas) |
| `js/data/` | `adapter-csv.js` (CSV z D_VYPR_POL), `dpb-data.js` (prístup k dátam), `grafikon-parsery.js` (.JR/.SM/CILE/STANICE), `kolaj_data.js` (pravidlá koľají), `raw_data.js` (statické kurzy z PDF) |
| `js/funkcie/` | jednotlivé časti appky: karta služby, burza, notifikácie, cestovné poriadky, žiadosti, zastávky, import CSV, prihlásenie, téma |
| `js/app/` | `hlavna.js` (hlavný stav a vykresľovanie – zatiaľ ešte veľký, bude sa deliť ďalej), `render-hook.js` |
| `data/<RRRRMMDD>/` | verzie grafikonu; platí najnovšia verzia k danému dňu |
| `tests/` | automatické testy čistej logiky |

Poradie načítania skriptov v `dpb_app_v11.html` je dôležité – nemeň ho.

## Testy

Potrebuješ Node.js. V priečinku projektu spusti: `node --test tests/*.test.mjs`

## Poznámky

- `dpb_raw_data.js` v koreňovom priečinku sa momentálne nikde nenačítava; nechané pre istotu, zatiaľ nemazať.

## Kontrola dát po novom exporte (v12)

`node tools/kontrola-dat.mjs export.csv 2026-10-18` – nič nemení, vypíše počet zahodených starých verzií riadkov a podozrivé miesta (bez vozidla v minulosti, prekrývajúce sa služby jedného vodiča, prekrytia služieb; viac vodičov na jednom kurze sa nehlási – je to začvik alebo hradenie). Pravidlo adaptéra: z viacerých verzií riadku (výpravenka + turnus + riadok + poradie) platí najnovšia podľa OPRAVILCAS. Ak sa pri úprave zmenil turnus, platí len najnovšia verzia; presné duplicity (rovnaký vodič, časy aj vozidlo v tom istom riadku) sa zlúčia a ostane nižšie poradie.

## Ikony dopravy (v13)
- `img/doprava/` – siluety trolejbusu, električky a autobusu (+ `*-podklad.png`, vyplnená silueta, ktorá zakrýva ikonu pod sebou).
- `js/funkcie/ikony-dopravy.js` – skladá trojicu nad logo DPB (úvodná a prihlasovacia obrazovka). Stredná ikona je zväčšená a určuje druh dopravy: `DpbIkony.nastavMod("elektricka" | "autobus" | "trolejbus")`, predvolený mód je v súbore (`PREDVOLENY_MOD`).
- Ikony sa točia ako kolotoč (úvodné roztočenie, pri nahrávaní dát točenie stále) a dobehnú do pokoja so strednou ikonou vybraného módu. Veľkosti a polomer: konštanty `V_ZADNA`, `V_PREDNA`, `POLOMER`, časy `INTRO_MS`, `SETTLE_MS`, `TURN_MS` v `ikony-dopravy.js`.
- Trakcia vodiča: adapter berie `TYPDOPRAVY` z riadkov vodiča (`raw.trakcie`), `DPBData.getTrakciaKod(rid)`; pri výbere vodiča na prihlasovacej obrazovke kolotoč dobehne na jeho trakciu. Mapovanie kódov (`KODY_TYPU`) je v `ikony-dopravy.js` – A = električka, T = autobus, O = trolejbus.
- Automatické pokračovanie (v13): ak sa stránka len obnoví (F5, Live Server, potiahnutie nadol), appka znovu načíta uložené CSV a prihlási rovnakého vodiča (`dpb_relacia` v localStorage, platí 12 h). Nové otvorenie stránky (adresa, záložka) zobrazí štandardne úvodnú obrazovku. Zoznam posledných štartov je v localStorage `dpb_starty` (typ: reload / navigate).
- Profil (`js/funkcie/profil.js`): meno, osobné číslo, trakcia a tlačidlo „Odhlásiť sa“ (vráti na výber vodiča a zruší automatické pokračovanie). Keď pribudne skutočné prihlasovanie, zmení sa len funkcia `odhlas()`.


## Zácvik na karte služby
Ak sa v D_VYPR_POL v stĺpcoch ZACVIK1–3 objaví osobné číslo, karta ukáže riadok „Zácvik“: vedúci vodič vidí „Zácvik: <meno zacvičovaného>“ a zacvičovaný vidí „Zácvik, vedie: <meno vedúceho>“. Rola sa berie z toho, či je vodič sám v stĺpci ZACVIK (zacvičovaný) alebo nie (vedúci). Vedúci sa hľadá v tom istom riadku výpravenky.


## Kódy neprítomností (STAVTURNUSU)
Názvy sú z firemného číselníka („Ostatné číselníky“), uložené v `js/data/ciselnik-stavov.js` (61 kódov, vrátane skratky a príznaku Zobraz). Karta neprítomnosti ukazuje názov z číselníka. Kód, ktorý v číselníku chýba, sa na karte zobrazí ako „kód N“ a `tools/kontrola-dat.mjs` ho nahlási.


## Časová os vodiča (etapa 2 dátového modelu)
`js/data/os-vodica.js` z čistých riadkov (po `DpbCistiRiadky.cisti`) zostaví pre každého vodiča a deň zoradené úseky: služba, pohotovosť, výpravca, záložné vozidlo 944, neprítomnosť. Každý úsek má druh, kurz, časy (koniec po polnoci +24 h zo skutočných časov), vozidlá, zácvik (vedúci / zacvičovaný + partner) a náhradu (kto za koho a prečo, napr. „Dolník – Dovolenka čerpaná“). Modul zároveň zbiera nejasnosti: `dvaja_pritomni_bez_zacviku`, `bez_vozidla`, `prekryv_sluzieb`, `neznamy_kod_stavu`.
Modul zatiaľ **nie je zapojený do appky** (vzhľad a funkcie sa nemenia). Slúži na overenie a ako základ etapy 3 (karty z osi).
Porovnanie so súčasnými kartami: `node tools/porovnaj-os.mjs export.csv` – skontroluje rovnaké dni, neprítomnosti, pokryté minúty a kurzy a vypíše chyby, ktoré os robí inak.


## Etapa 3, krok 1 – karty z osi
Karta neprítomnosti a základné polia obyčajnej služby (kurz, časy, stanice, vozidlá, minúty) idú z úseku osi (`js/data/karta-z-useku.js`). Predchodca, nasledovník, zácvik a prestávky dopĺňa zatiaľ adaptér. Minúty (`od_min`, `do_min`) sú teraz správne aj pri službách cez polnoc a pri úsekoch s plánovaným koncom po polnoci; vďaka tomu sa napr. úsek služby, ktorý je celý počas pohotovosti, vnorí do pohotovosti tak, ako to pravidlo hovorí.


## Etapa 3, krok 2 – pohotovosť a záložné vozidlo 944 z osi
Zlúčenie pohotovostí, vnorenie úsekov do pohotovosti a reťaze záložného vozidla 944 (karta „944“ s hradeniami) sa počítajú v `js/data/karta-z-useku.js` z úsekov osi. Výstup je oproti kroku 1 rovnaký, okrem minút (`do_min`) pri 91 kartách cez polnoc (84× 944, 7× pohotovosť), kde boli minúty v starej verzii zlé.


## Etapa 3, krok 3 – predchodca a nasledovník z osi
Predchodca a nasledovník na karte (aj výpravcovia KR/TR) sa počítajú v `js/data/karta-z-useku.js` z indexu prítomných úsekov podľa dňa (`indexDna`, `predNasl`, `predNaslVypravca`). Výstup je identický so starým na všetkých kartách exportu, načítanie veľkého exportu je však asi 4,5× rýchlejšie (v teste z ~13,5 s na ~3 s), lebo sa pre kartu už neprehľadávajú všetky riadky dňa.

## Etapa 3, krok 4 – prestávky a minúty výpravcov
Priradenie prestávok (kto jazdí striedača v čase prebratia) je v `pridajPrestavky` v `js/data/karta-z-useku.js`; používa index deň → kurz, nie prehľadávanie všetkých vodičov. Výstup je identický so starým na všetkých kartách exportu (4 567 kariet, 6 527 prestávok). Nočné karty výpravcov (TR/KR 18:00–06:00) mali `do_min` mylne 360 namiesto 1800 (110 kariet); teraz sa berú minúty z osi. Kontrola: `node tools/porovnaj-os.mjs <export.csv>` hlási 0 chýb minút.

## Upratanie karty striedača a výpravcu
Základ každej karty (SLUŽBA, POHOTOVOSŤ, TRKR aj STRIEDAČ) sa skladá na jednom mieste, `kartaZaklad` v `js/data/karta-z-useku.js`; v adaptéri ostalo len rozhodnutie o druhu karty a zácvik. Odstránené nepoužité funkcie (`getVehicles`, `popisStavu`). Výstup je identický na všetkých kartách exportu. Striedači v exporte nejdú cez polnoc (1 335 kariet), preto sa im minúty nepridávali.


## Význam ďalších stĺpcov exportu (podľa Romana)
- `DRUH_SLUZBY`: ranná, celodenná, odpoludňajšia, nočná, delená, záloha (zatiaľ sa nepoužíva).
- `GRFTYP`: typ použitého grafikonu (pracovný deň, prázdniny, sobota, nedeľa).
- `TYPVOZUVYPR`: interná informácia pre operátora, aký typ vozidla je minimum pre danú službu (vodič ju nepotrebuje, v appke sa nepoužíva).
- `RIDIC_PP`: interné číslo pracovného pomeru, nič neznamená (nerieši sa).
- `OZN`: v pôvodnom programe checkbox (áno/nie), či vodič už prišiel do práce; v appke sa nepoužíva.

## Pásy Dispečing a Výpravňa (pevné, neodrolujú sa)
- `js/data/vypravna-model.js` (čistá logika, testy v `tests/vypravna-model.test.mjs`): z kariet TRKR (dennáKR, nočnáKR, dennáTR, nočnáTR) zistí, kto je v danom čase „teraz“ a kto nasleduje; rozumie nočnej zmene z predošlého dňa aj nasledujúcej zmene z ďalšieho dňa.
- `js/funkcie/vypravna-pas.js`: pás „Dopravný dispečing“ pod červenou hlavičkou (+421 2 5950 7777, ťuk zavolá, bez ikony) a pás KR/TR nad spodným menu. Ťuk na KR alebo TR ponúkne obe čísla (KR: +421 2 5950 3429, +421 908 297 006; TR: +421 2 5950 2410, +421 908 297 011).
- Mená sa menia podľa zvoleného dňa, čas dňa je vždy aktuálny. Pásy sú viditeľné len na obrazovke Dnes po prihlásení. Dispečing sa nemení.
- Ak raz pôjdu aj autobusy a trolejbusy, doplnia sa ďalšie riadky v `vypravna-pas.js` (čísla v `CISLA`) a do modelu ďalšia skupina.
- Ikona telefónu pri predchodcovi a nasledovníkovi na karte sa ukáže len vtedy, keď je k vodičovi číslo (`before.phone` / `after.phone` v `dpb-data.js`); zatiaľ žiadne nie je.

## Burza služieb – skutočné voľné služby
- Pohotovosť sa v Burze volá „Dispozičný vodič“ s menším podnázvom „Sedavá záloha“; miesto: E1 = Dp. Trnávka, E2 = Dp. Krasňany (zobrazí sa ako „Od“ v detaile).
- `js/data/volne-sluzby.js` (testy `tests/volne-sluzby.test.mjs`): z CSV nájde služby bez vodiča. Do Burzy idú len štandardné služby (kurz v tvare linka/poradie, napr. 3/16) a pohotovosti; kurz E, Technologická, Skúšobná jazda, výcvik BUS a podobné sa vynechávajú. Voľná je každá časť služby (výpravenka + turnus + riadok + TRIDENI) bez prítomného vodiča, takže pri delenej službe sa ponúka len voľná časť. Neprítomný pôvodný vodič bez náhrady = voľná služba.
- Adapter vracia `volne` + `volneDni`; `DPBData` ich drží (pri novom importe sa nahradia len dni, ktoré export pokrýva).
- `js/funkcie/burza.js`: ukážkové (náhodné) služby sú preč. Vodič vidí službu, ak je jeho trakcie, ešte nezačala (len od aktuálneho času) a ten deň nemá žiadnu službu ani neprítomnosť. Vlastná rezervácia ostáva viditeľná. Neskôr pribudne kontrola povinných odpočinkov (miesto: `dostupna()` v `burza.js`).
- Rezervácia je stále len simulácia (schválenie sa nastavuje náhodne); skutočné odosielanie požiadavky na server príde neskôr.

## Zastávkový poriadok – všetky linky a všetky typy dňa (v32)
- Zastávka → odchody **všetkých liniek všetkých trakcií** (električky, autobusy, trolejbusy; linky 8NN sa zobrazujú ako X1, X3, …). Filtre: Nástupište, Linka, **Typ dňa** (číselný 1–9, zatiaľ bez názvov). Bez výberu typu platí kalendár (včera/dnes/zajtra); s výberom sa ukáže poriadok zvoleného typu.
- Dáta sa nečítajú zo surových .JR (28 MB), ale z predpočítaného indexu `data/<priečinok>/ZAST/<kód zastávky>.txt` (načíta sa len otvorená zastávka). Index vzniká nástrojom `node tools/zastavky-index.mjs data/<priečinok> [priečinok_s_exportom]`. Ak index chýba, použije sa staré čítanie .JR (len 1, 3, 4, 9).
- Nový export BS300 = nový priečinok `data/RRRRMMDD/` (STANICE.ZS, CILE.CL a ZAST/); platný sa vyberie podľa dátumu ako doteraz.
- Prázdne súbory .JR (421…, 931) sú v exporte zástupné, nemajú odchody.
- Službový cestovný poriadok (kurz) a grafikon kurzu fungujú pre všetky linky: priečinok platnosti `data/20261003/` obsahuje celý export (všetky `.JR` a `.SM`), čítanie ostalo nezmenené (len sa načíta súbor jednej linky).

## Vzhľad kariet (v34)
- Číslo linky/poradie na karte hrubšie (800). Pred časom služby ikona hodín, pred miestom ikona polohy, pred prvým vozidlom ikona druhu vozidla (7xxx električka, 6xxx trolejbus, ostatné autobus; fiktívne 5000 a 7000 bez ikony) – všetky úplne vľavo.
- Neprítomnosť: linka, čas a vodiči zosvetlení, dôvod neprítomnosti veľký a červený.
- Burza: ikona hodín pri čase (odsadený), v detaile trasa v jednom riadku „od – kam“ s ikonou polohy.
- Výpravňa: nadpis VÝPRAVŇA a zaoblený kontajner.

## Názvy pohotovostí a výpravcov (v39)
- Pohotovosť E1/E2 sa všade volá „Dispozičný vodič“ (Sedavá záloha); E1 = Dp. Trnávka, E2 = Dp. Krasňany. Denná/nočná KR/TR výpravca = „Denný / Nočný výpravca“; KR = výpravňa Krasňany, TR = výpravňa Trnávka. Všetko v `js/data/nazvy.js`. Oficiálne názvy zastávok z grafikonu sa nemenia.
- Ukážkové notifikácie vymazané, zoznam je prázdny, kým neprídu skutočné.
- Filtre zastávky (nástupište, linka, typ dňa) sú každý v jednom riadku, posúvajú sa do strán, aby zostalo miesto na odchody (v40).

## Kontakty, žiadosti, tykanie (v41)
- Kontakty (dispečing, výpravne, zamestnávateľský prehľad) sú v `js/data/kontakty.js`. Vymyslené kontakty sú preč; prehľad ukáže „Kontakty sa pripravujú“, kým sa zoznam nedoplní (cez `DpbKontakty.nahrad`).
- Žiadosti z menu karty zatiaľ nič neodosielajú: ukážu „Pripravuje sa“.
- Texty aplikácie tykajú (Tvoja rezervácia, Vyber vodiča, Nahraj CSV…).

## Rýchlosť na slabých mobiloch (v42)
- Súbory sa sťahujú stlačené (`.gz`, 4–6× menšie). Pôvodné súbory ostávajú ako záloha: ak `.gz` chýba alebo ho prehliadač nevie rozbaliť, použijú sa nestlačené.
- `tools/gzip-data.mjs [--jr] data/<priečinok>` vyrobí `.gz` pre ZAST, STANICE.ZS, CILE.CL (s `--jr` aj pre všetky `.JR`/`.SM`). `tools/zastavky-index.mjs` stlačené kópie vyrobí sám.
- `tools/obehy-split.mjs data/<priečinok>` rozdelí `.JR` na obehy (`OBEH/<kód>.txt`). Službový grafikon si stiahne jeden obeh (~10 KB) namiesto celého `.JR` (až 2 MB). Ak `OBEH/` chýba (starší export), použije sa celý `.JR`. Overené: všetkých 2158 obehov dáva rovnaký výsledok ako celý `.JR`.
- Pri novom exporte treba po vložení do `data/<priečinok>/` spustiť: `zastavky-index.mjs`, `obehy-split.mjs`, `gzip-data.mjs --jr`.
- Načítané zastávky a grafikony sa držia v pamäti (opakované otvorenie je okamžité).
- Výpadok siete v zastávkovom poriadku: hláška „Odchody sa nepodarilo načítať“ + tlačidlo „Skúsiť znova“ (predtým sa zle ukazovalo „Žiadne odchody“).
- Odstránený nepoužívaný `lucide.min.js` z načítania (388 KB, nikde sa nepoužíval).
- Namerané (6× pomalší procesor, 3G 500 kb/s): zastávka 5,3 → 1,8 s; službový grafikon linky 3: 32 → 1,7 s; striedač 53 → 1,9 s; štart aplikácie 14,5 → 8,1 s (bez kompresie servera; na hostingu s gzip je to ešte menej).

## Oprava liniek pri prejazde, nočné linky, ciele, kalendár (v43)
- Spoje linky, ktorú jazdí služba inej linky (31 v 39.JR, 61 v 40.JR, 78 v 67.JR, 25 v 29.JR, 92 v 68.JR, 33 v 32.JR, 90 v 192.JR…), sa v zastávkovom poriadku vedeli pod číslom súboru. Teraz sa berie linka zo spoja (`L031`) a v zozname je „31 (39/5)“ = linka 31, služba 39, kurz 5. Index má pri prejazde 7. stĺpec (číslo súboru/služby).
- Cieľ spoja sa berie z `.SM` jeho vlastnej linky (31.SM), nie z `.SM` súboru. Rovnako v službovom grafikone (`doplnSM`): predtým sa pri prejazde ukazovalo „→ S01“.
- Linky 4NN sú nočné linky NNN (421 = N21, 470 = N70…), v aplikácii sa ukazujú ako N21, N70 (ako 8NN = X).
- Ciele s kódom pod 100 sa nenachádzali (v CILE.CL sú kódy s nulou, v indexe bez nuly) – opravené.
- Kalendár: pridané prázdniny 29.–30.10.2026 a 23.–31.12.2026 podľa GTFS (platný 5.10.–31.12.2026). Po 31.12. doplniť z ďalšieho GTFS (`js/core/kalendar.js`).
- Overené proti GTFS (porovnanie zastávka+nástupište+linka+čas): zhoda 99,99 % na všetkých typoch dňa. V BS300 sú navyše len linky, ktoré GTFS nemá (X1, X3, X4, X9, X71, 9xx).
- Odchody sa nezmenili (598 skupín zastávok: rovnaké množiny odchodov, zmenilo sa len pomenovanie linky a cieľ).
- Význam typov dňa: 1 = pracovný deň, 2 = sobota, 3 = nedeľa/sviatok, 4 = pracovný deň počas prázdnin. Typy 5–9 sú zvláštne varianty.

## Kontrola dát (v43)
- `node tools/kontrola-dat.mjs data/<priečinok> [gtfs_priečinok]` – nezávislá kontrola po každom novom exporte (po `zastavky-index`, `obehy-split`, `gzip-data --jr`). Vlastným parserom načíta zdrojové `.JR/.SM/CILE.CL` a overí: (1) každý odchod v zastávkovom indexe je v zdroji a nič nechýba, vrátane nástupišťa a kódu cieľa, (2) každý cieľ sa dá previesť na názov, (3) všetky obehy v `OBEH/` sú rovnaké ako v `.JR`, (4) každý `.gz` je bajt po bajte rovnaký ako originál. Pri chybe skončí s chybou. S GTFS vypíše informatívnu zhodu (20261003: 100 % odchodov GTFS je v BS300; 12 odchodov liniek N91/N93 na Jasovskej má iné nástupište).
- Je aj ako test `tests/kontrola-dat.test.mjs` (spúšťa sa spolu s ostatnými).

## Nadpisy spojov v službovom grafikone (v44)
- Spoj inej linky jazdený službou má v grafikone nadpis „N80 (91/51)“ (linka spoja, v zátvorke služba/kurz), bežný spoj „91/51“. Cieľ sa berie z `.SM` linky spoja.
- `kontrola-dat.mjs` navyše overuje, že **každý** z 64 415 spojov má cieľ, ktorý sa dá previesť na názov.
- Overené v prehliadači na všetkých 2 158 obehoch: každý nadpis má správnu linku, cieľ (nie „S03“) a počet spojov zodpovedá `.JR`.

## Vzhľad zoznamu odchodov (v45)
- Nástupištia sú písmená podľa GTFS (A, B, E, F…). Zdroj: `data/<priečinok>/NAST.txt`, vyrobí ho `node tools/gtfs-nastupista.mjs <gtfs> data/<priečinok>`. Nástupište bez písmena v GTFS (37 technických) ukáže číslo. Starší export bez `NAST.txt` ukazuje čísla ako doteraz.
- Medzi časom a linkou je nástupište, len ak je v zozname viac ako jedno nástupište.
- Linky sú zarovnané na lomku (40/18, 4/6, 31 (39/5)); cieľ je odsadený.
- Názvy filtrov (Nástupište, Linka, Typ dňa) sú ukotvené vľavo, posúvajú sa len tlačidlá; poloha posunu ostáva po kliknutí.

## v46 – číslo vozidla v zozname odchodov zastávky
- Medzi linku a cieľ sa zobrazí číslo vozidla, **len pre odchody v kalendárny dnešok** (iné dni ho nemajú).
- Zdroj: importované turnusy (karty SLUŽBA, kľúč „linka/kurz“, interval vozidla od ≤ čas < do; po polnoci sa počíta s prechodom cez 24:00). Pri prejazdových spojoch sa použije linka služby (napr. 61 (40/18) → 40/18).
- Stĺpec sa zobrazí iba ak aspoň jeden viditeľný riadok vozidlo má; inak je zoznam ako predtým.
- Overené voči nezávislému výpočtu (265/265 odchodov zhodných).

## v47 – písmená nástupíšť aj tam, kde ich GTFS nemá
- Overené na GTFS: všetkých 1 378 nástupíšť s písmenom sa riadi poradím v abecede (01=A, 02=B … 26=Z), bez výnimky.
- GTFS má stále prednosť; ak nástupište v GTFS chýba (napr. depové 01/02/05 na Depe Jurajov dvor, 19/22/23/25/26 inde), písmeno sa dopočíta z čísla. Nad 26 ostáva číslo.

## v48 – školské spoje (linka 932 = „Šk“)
- Neverejné školské spoje (cieľ v CILE.CL „Školská linka N“, v GTFS ich niet okrem Školskej linky 6) sa v zozname odchodov ukážu ako **Šk N** (napr. „Šk 4/4“, pri prejazde „Šk 6 (36/1)“). Cieľ je **názov poslednej zastávky** spoja (Žatevná, OC Bory, Mokrohájska …).
- Rovnako v grafikone (nadpis spoja aj cieľ).
- V indexe `ZAST` je cieľ školského spoja zapísaný ako `S<N>:<skupina poslednej zastávky>`; `tools/zastavky-index.mjs` aj `tools/kontrola-dat.mjs` to rešpektujú. Všetky priečinky `data/*` boli prebudované (počty odchodov nezmenené).
- Služobné jazdy linky 932 (do/z depa) majú rovnakú školskú linku ako obeh, v ktorom idú (v obehu je vždy jedna), a tiež cieľ = posledná zastávka (napr. „Šk 2/2 → Dp Trnávka“). Pravidlo je v `tools/zastavky-index.mjs`, `tools/kontrola-dat.mjs` (nezávislý prechod) aj v grafikone (`cielSkolskehoSpoja`).
- Kontrola dát s GTFS teraz priraďuje 932 ↔ Šk: zhoda 100 % aj pre túto linku.

## v50 – grafikon: farebné pásy spoja, úseky bez cestujúcich; skrytie liniek X
- **Pás spoja** (linka/poradie + cieľ) je celý farebný: bežný spoj tmavý (biely text; školské spoje Šk sú ako bežné), **nočná linka tmavomodrý**, **služobná jazda / presun len po vozovni (Dp, Depo) šedý** (jemnejšia inverzia). Riadky takého úseku majú tiež šedé pozadie, zastávky „Dp xxx“ sú šedé vždy.
- Riadok „Teraz“ ostáva svetlý a čitateľný aj v šedom úseku. Farby platia v svetlom aj tmavom režime (`--np-bg`, `--np-fg`, triedy `.np`, `.sk`, `.noc` v `style.css`).
- Opravené: služobné jazdy školských obehov sa označia celé (nielen riadok Dp).
- **Linky X (8NN) a ostatné 9NN** (okrem školských Šk) sa v zozname odchodov zastávky **neponúkajú** – sú to náhradné/technické linky za električky pri výpadku. Funkcia `skrytaLinka` v `js/funkcie/zastavky.js`; ak sa niektorá z nich (napr. 908) objaví v GTFS s cestovným poriadkom, vyberie sa z nej.

## v52 – oprava spodného menu
- Po zatvorení okna „Ces. poriadky“ zostávalo zvýraznené „Ces. poriadky“, hoci bola vidieť obrazovka Dnes. Menu sa teraz vráti na záložku, ktorej obsah je vidieť (Dnes / Burza / Profil).

## v53 – obrazovka Dnes: dátum v jednom riadku, Výpravňa sa zbaľuje
- Deň a dátum („Štvrtok 15. 10. 2026“) sú v jednom riadku (na veľmi úzkom displeji sa zalomia).
- Box **Výpravňa** je predvolene zbalený (jeden slabý riadok s šípkou); ťuknutím sa rozbalí (KR/TR, kto je a kto nasleduje; ťuknutie na meno ponúkne volanie). Voľba sa pamätá (`localStorage`, `vypOtvorene`).

## v54 – kontrasty písma, popisky Výpravne
- Šedý pomocný text (`--text-3`) je tmavší (svetlý režim) / svetlejší (tmavý režim): kontrast ≥ 4,5 : 1 (predtým 3,5 / 2,8). Červený text na tmavom podklade používa `--red-text` (svetlejšia červená). Neaktívne záložky Zastávkový/Služobný sú plne biele.
- Minulé odchody v zozname sú menej zoslabené (60 % namiesto 40 %), minulé riadky grafikonu 55 % namiesto 35 %.
- Rozbalená Výpravňa má popisky stĺpcov „Teraz“ a „Nasleduje“.
- Overené automatickým meraním kontrastu na obrazovkách Dnes a Zastávka v svetlom aj tmavom režime. Zostáva: biele písmo na červenej (4,0 : 1, značková červená) a zámerne zoslabené minulé riadky.

## v55 – karta Dnes: šípka, ikona prepínača
- Šípka pri mene kolegu (preberám od / odovzdávam) je väčšia, tučná a červená; kto predchádza a kto nasleduje sa čita z polohy mena (nad / pod kartou).
- Ikona vpravo hore ukazuje, na čo sa prepne: v kartách = zoznam, v zozname (mesiac) = karta. Mení sa aj popis pre čítačky obrazovky.

## v56 – odchody zastávky: skrývací Filter, smer nástupišťa
- **Filter** (Nástupište, Linka, Typ dňa) je skrývací box ako Výpravňa: predvolene zbalený, v záhlaví je súhrn zapnutých filtrov (napr. „Nást. A · Linka 1, 4“), tlačidlo **Zrušiť filtre** sa ukáže, keď niečo svieti. Stav (otvorený/zbalený) sa pamätá (`zastFilterOtvoreny`).
- **Smer nástupišťa:** pri písmene nástupišťa je „· do centra“ alebo „· z centra“ (nič, ak je smer nejasný alebo je zastávka v centre).
  - Údaje: `data/<priečinok>/SMER.txt(.gz)`, vyrába ich `node tools/smer-nastupist.mjs data/<priečinok>` (spúšťa sa po `zastavky-index`/`gtfs-nastupista`).
  - Spôsob: z .JR sa pre každý spoj porovná vzdialenosť od centra tejto a ďalšej zastávky; nástupište dostane smer, ktorý má ≥ 75 % hlasov. Zastávky bližšie ako 350 m k centru = nejasné.
  - Centrum (Hlavné nám.) je konštanta `CENTRUM` v `tools/smer-nastupist.mjs`. Je to priblíženie, nie ručná tabuľka – ak niekde nesedí, dá sa to opraviť výnimkou.

## v57
- Filter zastávok: nástupištia iba písmená (bez legendy smeru), implicitne všetko zapnuté, typ dňa podľa kalendára; názvy Po–Pi, So, Ne, Prázdniny (ostatné typy zostávajú číslom).
- Vyhľadávanie zastávok: ★ obľúbené, naposledy použité a „Zastávky v okolí“ (GPS funguje iba cez HTTPS/localhost).

## v58 – PWA
- `manifest.webmanifest`, ikony `img/icon-*.png`, `sw.js` (service worker), `js/funkcie/pwa.js`, `pwa-manifest.js` (generuje sa).
- Appka (HTML/CSS/JS) ide najprv zo siete (vždy čerstvá), pri výpadku alebo slabom signáli (3,5 s) z pamäte. Dáta grafikonu idú z pamäte; aktuálny a novšie priečinky sa stiahnu na pozadí (~16 MB), potom „Offline pripravené“.
- Nová verzia: dole sa ukáže lišta „Je nová verzia appky – Obnoviť“.
- **Po každej zmene appky alebo dát spusti:** `node tools/pwa-build.mjs` (ja to robím pri každom zipe).
- Funguje len cez HTTPS alebo `localhost` (nie cez `http://172.…`).

## v59
- Prihlásenie: pole „Hľadaj vodiča (meno alebo číslo)“ nad zoznamom (`js/funkcie/vyber-vodica.js`); hľadá bez diakritiky a podľa viacerých slov, zoznam ostáva.
- Import CSV: širší výber súborov v mobile.

## v60 – automatický export z databázy
- `export-z-db/` : skript `export_vypr_pol.py` + `nastavenia.ini` + `SPUSTIT.bat`, `NAPLANOVAT.bat`, `ZRUSIT_PLAN.bat`, `NAVOD.txt`.
- Dopyt: `SELECT * FROM D_VYPR_POL WHERE DATUM > '2026-08-31' AND TYPDOPRAVY = 'A'` (bez ORDER BY ako v DBeaveri), CSV v rovnakom tvare ako export z DBeaveru.
- Neprepíše posledný dobrý súbor pri chybe alebo podozrivo malom počte riadkov; pri nezmenených dátach súbor neprepisuje.

## v61
- Profil: karta „Dáta“ (názov súboru, kedy načítaný, pred koľkým časom) a tlačidlo „Načítať nové dáta“ – vyberieš nový CSV (napr. z Disku), vodič ostáva prihlásený a karty sa prekreslia. Ak vodič v nových dátach nie je, odhlási sa.

## v62
- PWA: nová verzia sa ohlási spoľahlivo aj za hostingom s 10-minútovou pamäťou (GitHub Pages): číslo zostavenia je priamo v `sw.js`, appka sa pýta servera vždy znova (no-cache), registrácia s `updateViaCache: none`. `node tools/pwa-build.mjs` ho zapisuje sám.

## v63 – Exporty
- Mesačný zoznam: vedľa prepínača zoznam/karty je ikona exportu (viditeľná len v zozname) → PDF (tlač „Uložiť ako PDF“), Excel (.xlsx), Kalendár (.ics).
- Menu karty služby: „Zapísať do kalendára“ (otvorí Google Kalendár s predvyplnenou udalosťou) a „Export do ICS“ (súbor pre Apple/Android/Outlook).
- ICS obsahuje len služby (nie neprítomnosti), stabilné UID, časová zóna Europe/Bratislava. Kód: `js/funkcie/export.js`.

## v64 – Export: súhrn mesiaca, sviatky, budík
- PDF a Excel obsahujú súhrn mesiaca (počet služieb, hodiny, víkendy, sviatky, dni bez služby, neprítomnosti).
- Sviatky v PDF/Exceli sú červenkasté, víkendy sivé.
- ICS má upozornenie (VALARM) 60 min pred službou (`localStorage dpb-budik-min`, 0 = vypnuté; nastavenie v Profile pribudne).

## v65 – okienko exportu používa farby témy (tmavý režim)

## v66 – PDF exportu: A4 na výšku, menšie písmo, mesiac na jednu stranu

## v67 – zostať prihlásený + nechať obrazovku zapnutú
- Prihlásenie sa obnoví pri každom otvorení appky (až do odhlásenia v Profile, max. 90 dní).
- Profil: prepínač „Nechať obrazovku zapnutú“ (Screen Wake Lock, len HTTPS, `js/funkcie/obrazovka.js`).

## v68 – záložka Hľadať
- Dole nová záložka: vyhľadávanie vodiča (meno/os. č.), vozidla a služby/kurzu (4/9, 4) pre zvolený deň, vo všetkých vodičoch z načítaných dát. Šípky ‹ › menia deň, klik na dátum = dnes. Označuje „● teraz“. `js/funkcie/hladat.js`.

## v69 – vozidlo na karte 944
- Karta služby 944 (záložné vozidlo) teraz nesie vozidlo (predtým sa z CSV zahodilo a ukazovalo „—“). Opravené v `karta-z-useku.js`.
- Hľadať zahŕňa aj vozidlá z hradení. Porovnanie všetkých kariet s v68 na reálnom CSV: zmenili sa len karty 944 (vozidlo).

## v70 – vozidlo viditeľné na karte 944
- Karta služby 944 teraz zobrazuje číslo záložného vozidla (ikona + číslo, rovnako ako pri bežnej službe). Rovnaké číslo sa zlúči do jedného riadka.

## v71 – karta 944: vozidlo s časmi
- Vozidlo na karte 944 sa zobrazuje s časmi úsekov (ako pri bežnej službe), nie zlúčené. Medzi nimi sú hradenia.

## v72 – karta 944: vozidlo ako jeden riadok
- Vozidlo na karte 944 = jeden riadok od prvého výskytu na 944/x po koniec posledného úseku vrátane hradení tým istým vodičom (napr. `7509 • 04:00–13:45`). Rôzne vozidlá v jednej službe zostávajú osobitne.

## v73 – karta 944: miesto
- Karta 944 ukazuje miesto (odkiaľ prvý vlastný úsek 944 vychádza – kam posledný prichádza), rovnako ako bežná služba. Aj export (PDF/Excel/ICS) tak má trasu pri 944.

## v74 – Upozornenia na zmeny
- `js/funkcie/zmeny.js`: pri načítaní dát porovná s uloženou snímkou (aktuálny + minulý mesiac, 60 dní dopredu) a pošle správy do zvončeka (kategória Zmena): služba/čas, pridelené vozidlo, striedaný vodič (preberáš od), striedajúci vodič (odovzdáš), neprítomnosť. Prvé načítanie len uloží východiskový stav. Staršie dáta ako uložená snímka sa ignorujú.
- Karta zmenenej služby má žltý pulzujúci pásik „!!! ZMENA … !!!“ hore aj dole; klik ho poznačí ako prečítaný (uložené po vodičoch).
- Nové voľné služby v Burze (rovnaké pravidlá ako Burza: ešte nezačaté, rovnaká trakcia, deň bez vlastnej služby) → správa v zvončeku (kategória Burza).
- Správy zo zvončeka sa ukladajú po vodičoch (50 posledných); `window.Notif` je teraz dostupné.

## v75 – Automatické načítanie z Disku Google
- Nové súbory `js/funkcie/disk-google.js` a `disk-google-config.js`. Kým je `clientId` v configu prázdny, karta „Disk Google“ v Profile sa nezobrazí.
- Prihlásenie cez Google (scope `drive.readonly`), appka nájde `D_VYPR_POL.csv` podľa názvu, porovná `modifiedTime` a stiahne len novší súbor → `_nacitajNoveData`.
- Kontrola: po prihlásení pri prvom dotyku, pri návrate do popredia (max. raz za 10 min) a ručne tlačidlom v Profile.
- Obmedzenia: appka musí byť otvorená; token ~1 h; na iPhone v PWA môže prihlasovacie okno zlyhať (ručné načítanie ostáva).

## v77 – Disk Google na úvodnej obrazovke
- Tlačidlo „Načítať z Disku Google“ pod „Nahrať CSV“ (zobrazí sa len keď je v configu clientId), aby sa dalo začať aj bez ručného nahrávania súboru.

## v78 – Disk Google: menej výziev
- Prístupový token sa uchová do vypršania (~1 h), okno Google sa otvára najviac raz za otvorenie appky; návrat do popredia kontroluje Disk len s platným tokenom.

## v79 – Otvorenie vždy na dnešnom dni
- Ak vodič nemá dnes službu (voľno), appka sa už neotvorí na poslednom dni so službou, ale na dnešku (ak je dnes v rozsahu dát).

## v80 – iPhone na celú obrazovku
- Výška hlavičky a dolnej lišty teraz zahŕňa bezpečné okraje (výrez/status bar hore, lišta domov dole); predtým sa hlavička orezávala.
- V standalone režime na iOS telo vypĺňa celú obrazovku (position: fixed).
- Profil: diagnostický riadok (rozmery okna, obrazovky, okraje).

## v81 – Animácia ikon pri načítaní z Disku Google

## v82 – Kolotoč ikon sa už „nezasekne“
- nacitava(false) platí aj keď je obrazovka skrytá; ťuknutie na ikony roztočí kolotoč znova (iPhone).

## v83 – Upozornenie na zmenu ako mini karta
- Namiesto žltého blikajúceho pásika (hore aj dole) je pod obsahom karty jedna mini karta: červená s bielym textom (v tmavom režime svetlá), jemne „dýcha“.
- Text podľa zmeny: Pridalo/Zmenilo/Odobralo sa vozidlo; Pridal/Zmenil sa/Odpadol striedaný/striedajúci vodič; Pridala/Zmenila sa služba; Pridala/Zmenila sa neprítomnosť; detail (napr. „7444 → 7509“).
- Ťuknutím na mini kartu sa zmena poznačí ako prečítaná. Nové služby v Burze ostávajú len v zvončeku.

## v84 – Upozornenie na hradenie
- Hradenia na karte 944 sa sledujú samostatne od vlastného vozidla karty: „Pridalo sa hradenie“, „Odpadlo hradenie“, „Zmenilo sa hradenie“ (mini karta + zvonček); vozidlo hradenia sa nehlási zvlášť.
- Staré uložené stavy hradenia nemajú: prvé porovnanie po aktualizácii hradenie nehlási.

## v85 – Menu na karte Voľno
- Tri bodky vpravo hore na karte „Voľno“: minulosť = Reklamácia; dnes = Reklamácia, Žiadosť o službu, Zmena stavu; budúcnosť = Žiadosť o službu, Zmena stavu. Zatiaľ zástupné („Pripravuje sa“), modály sa doplnia. Burza na karte ostáva.

## v86 – Menu na kartách: oprava minulých dní
- Chyba: menu na kartách nepoznalo „dnes“ (window.formatDateKey neexistuje, je v window.DpbCas), takže minulé dni mali menu ako budúce. Opravené: minulý deň má Reklamáciu.
- Karta neprítomnosti: tlačidlo menu už nie je zosvetlené (bolo takmer neviditeľné).
- Poznámka: window.formatDateKey sa nesprávne volá aj v grafikon-kurz.js a karta-sluzby.js (riadok ~629); nechané bez zmeny, treba posúdiť samostatne.

## v87 – Reklamácia len pre minulosť
- Z menu karty Voľno odstránená Reklamácia pre dnešný deň (platí len pre minulé dni).

## v88 – Menu karty služby: dnes
- Dnes (SLUŽBA, 944, STRIEDAČ, POHOTOVOSŤ, TRKR): Grafikon, Zmena stavu, Nahlásiť poruchu vozidla (len ak je vozidlo; s číslom, ak je jedno), Nahlásiť udalosť, Zmena služby. Kalendár/ICS pre dnes skryté. Zmena stavu zatiaľ otvára doterajšie okno neprítomnosti (Lekár/PN/Iné); ostatné „Pripravuje sa“.
- Zistené: pre obyčajnú službu v budúcnosti je dnes len „Žiadosť o službu“ (pôvodný kód kontroloval údaj, ktorý majú len karty neprítomnosti). Budúcnosť sa rieši ďalej.

## v89 – Menu karty služby: budúcnosť
- Budúca služba (SLUŽBA, 944, STRIEDAČ, POHOTOVOSŤ, TRKR): Grafikon, Zmena stavu, Zmena služby, Zapísať do kalendára, Export do ICS. Bez udalosti a poruchy vozidla.

## v90 – Bez kalendára v menu karty
- Z menu karty odstránené „Zapísať do kalendára“ a „Export do ICS“. Export do kalendára je len zo zoznamu služieb (tlačidlo Export). Funkcie DpbExport.kartaGoogle/kartaIcs ostávajú v export.js nevyužité.

## v91 – Striedač: vykonané / nevykonané pri prestávkovaných riadkoch
- Nový súbor js/funkcie/prestavka.js. Pri každom riadku karty striedača ikona: zelená fajka (vykonané), po ťuknutí červený krížik + okno „Nezabezpečená pracovná prestávka“ s dôvodom (meškanie, porucha vozidla, zmena v prevádzke, iný dôvod).
- Len v deň výkonu je ikona aktívna; minulosť = len zobrazenie (štandardne fajka, krížik ak bolo hlásenie); budúcnosť = bez ikony.
- Zrušenie okna vráti fajku; po „Pripraviť hlásenie“ ostane krížik (zamknutý) a otvorí sa zdieľanie hotového textu (alebo sa skopíruje).
- Stav v localStorage: dpb-prest-<os. číslo>. Opravené: buildStrList pre striedača nedostával `service`.

## v92
- Menu karty služby: kým služba práve beží (dnes, medzi začiatkom a koncom), sa nezobrazuje „Zmena stavu“ ani „Zmena služby“. Pred začiatkom aj po skončení ostávajú.

## v93
- Po skončení dnešnej služby sa menu karty správa ako pre minulý deň (Grafikon, Reklamácia).

## v94–v95
- Menu kariet sa prepína živo: appka si nastaví časovač presne na najbližší začiatok/koniec dnešnej služby (bez kontroly každú minútu) a kontroluje aj pri návrate do appky. Otvorené menu sa prepne až po zatvorení.

## v96
- iPhone: hlavičky celoobrazovkových okien (grafikon, cestovný poriadok so záložkami Zastávkový/Službový) sú pod stavovým riadkom; login/import obrazovka, zoznam upozornení a spodné okná majú safe-area okraje; okná v iPhone PWA siahajú až na spodok obrazovky (100lvh – na overenie na reálnom iPhone).

## v97
- iPhone: prejdené všetky obrazovky (štart, login, Dnes, zoznam, upozornenia, Burza, Ces. poriadky, Hľadať, Profil, menu karty, grafikon, žiadosť) so simulovaným výrezom; hláška (toast) je nad spodnou lištou.

## v98
- Profil: diagnostický riadok doplnený o merania výšky (inset, lvh, svh, dvh, visualViewport, body) kvôli odrezanému spodku na iPhone.
- v99: vrátené pravidlo 100lvh pre okná (odrezávalo spodok); okná zasa vypĺňajú presne tú plochu, ktorú iPhone appke dá (inset:0).

## v100
- Nový stoh okien (DpbOkna) a prvé vrstvené okno „Zmena stavu“ z menu karty (služba, voľno, neprítomnosť): výber (Dovolenka / PN / Lekár / Voľno / Iné; pri neprítomnosti aj „Ukončiť …“) → formulár od–do (predvyplnený dňom karty; koniec môže ostať prázdny pri PN a Iné) → hotový text hlásenia cez zdieľanie/schránku. Pri „Ukončiť“ ešte okno „Požiadať o službu?“.

## v101
- Okno „Žiadosť o službu“ / „Zmena služby“ (z menu karty): skupiny Chcem a Nechcem, každá s typom služby (ľubovoľná/ranná/odpoludňajšia/delená), časom nástupu od–do, časom ukončenia od–do a linkou; poznámka; hotový text cez zdieľanie/schránku.

## v102
- Žiadosť o službu / Zmena služby: čas zredukovaný na dve polia „Nástup po“ a „Ukončenie do“ v každej skupine (Chcem / Nechcem).

## v103
- Žiadosť o službu: pri „Nechcem“ sú polia „Nástup pred“ a „Ukončenie po“ (pri „Chcem“ ostáva „Nástup po“ a „Ukončenie do“).

## v104
- Okno „Reklamácia“ (minulý deň): zaškrtneš, čo reklamuješ – Stav; pri službách aj Čas nástupu, Čas ukončenia, Vozidlo, Chýbajúce hradenie, Chýbajúci vykonaný zácvik (zácvik nie pri striedačovi) – a doplníš správnu hodnotu; pri voľne/neprítomnosti len Stav. Výstup ako text hlásenia.

## v105
- Menu dnešnej služby: „Nahlásiť poruchu vozidla“ + „Nahlásiť udalosť“ zlúčené do jedného „Nahlásiť“. Okno: Čo (Porucha vozidla / Iné), Komu (Dielňa / Dispečing / Výpravňa, aj viac), popis; pri poruche výber vozidla, ak ich je viac. Ďalšie vrstvy podľa typu pribudnú neskôr. (Striedač: vozidlá z riadkov zatiaľ nie sú v ponuke.)

## v106
- Grafikon sa už nezatvára potiahnutím prstom nadol (zatváral sa aj omylom); zatvára sa len tlačidlom Zavrieť.
- Grafikon otvorený z Cestovných poriadkov (Službový, kurz): po Zavrieť sa vrátiš do okna Cestovných poriadkov (predtým ostala prázdna obrazovka).

## v107
- Hľadať: ťuknutie na výsledok (kurz) otvorí pod kartou malé menu: „Grafikon“ (malé okno so 7 zastávkami: 3 pred, aktuálna, 3 za; pri dnešku sa obnovuje; mimo služby vodiča ukáže začiatok / koniec jeho služby) a „Koho stretne“ (električky idúce oproti po rovnakom úseku, s menom, kurzom a vozidlom).
- Menu karty služby (električky 1/3/4/9): nová položka „Koho stretnem“. Výpočet je plánovaný podľa grafikonu (js/funkcie/stretnutia.js), nie živá poloha.

## v108
- Hľadať: menu pod výsledkom má len „Grafikon“ (mini, 7 zastávok). „Koho stretnem“ ostáva samostatne v menu vlastnej karty služby (električky).

## v109
- „Koho stretnem“ je v menu karty služby (električky 1/3/4/9) len pre dnešný deň a kým služba nie je skončená (po skončení sa menu správa ako pre minulý deň).

## v110
- Mini grafikon (Hľadať) a „Koho stretnem“ sú živé pri dnešnom dni: už prejdené zastávky/stretnutia zhora miznú, nové pribúdajú dole (grafikon sa obnovuje každých 5 s, stretnutia každých 10 s).

## v111
- Mini grafikon aj „Koho stretnem“ ako koliesko: najbližší čas je v strede, zväčšený a červený, odídené riadky nad ním a prichádzajúce pod ním blednú so vzdialenosťou. „Koho stretnem“ má tlačidlo „Zobraziť všetky“ / „Späť na najbližšie“.

## v112
- Mini grafikon a „Koho stretnem“: koleso sa dá listovať prstom (celá trasa / všetky stretnutia), vidieť je 7 riadkov, stred je zväčšený a zvýraznený. Samo sa centruje na najbližší čas; po ručnom posune 20 s drží polohu. „Koho stretnem“ má tlačidlo „Na najbližšie“.

## v113
- Opravené párovanie „Koho stretnem“: porovnáva úseky medzi zastávkami, ktoré majú oba spoje spoločné (električka môže zastávku vynechať, napr. STU len v jednom smere). Predtým takéto stretnutia vypadávali (napr. 9/10 × 9/5 25.10. o 10:43; zo 106 na 148 stretnutí).

## v114
- „Koho stretnem“: pridané vnútorné rozhranie pre kontrolu úplnosti (nezávislé porovnanie 77 506 dvojíc spojov dňa: výpočet a kontrola sa zhodli na 100 %). Funkčne bez zmeny.

## v115
- Koho stretnem: nový algoritmus. Hrana = dvojica susedných zastávok MOJHO spoja (smer pohybu). Hľadá sa spoj idúci po tom istom úseku opačne čas stretnutia z lineárnej interpolácie. Názov „medzi X a Y“ vždy len susedné zastávky, takže už nevznikajú neexistujúce hrany.

## v116
- Koho stretnem: odstránená kontrola dĺžky úseku z v115 (vyhadzovala platné stretnutia, napr. 9/5 o 12:14). Názvy hrán ostávajú podľa susedných zastávok môjho spoja.

## v117
- Koho stretnem: spoje, ktoré medzi dvoma spoločnými zastávkami idú INOU trasou (obe strany majú vlastné zastávky navyše, napr. linka 4 cez Most SNP vs. linka 9 cez Poštovú/Kapucínsku), sa už nepočítajú ako stretnutie.

## v118
- Koho stretnem: nová logika na úsekoch. Úsek = dvojica susedných zastávok jazdy; stretnutie = opačný úsek druhého spoja v prekrývajúcom sa čase. Vynechaná zastávka (STU) = dlhší úsek platí za všetky pokryté úseky. Ručné pravidlo: koľaje od Kapucínskej a Chatam Sófer sa pred Kráľovským údolím spájajú (úseky 0141<->0281 a 0439<->0281 sú ten istý úsek). Nahrádza záplaty z v115–v117.

## v119
- Koho stretnem: ručné pravidlo 2 – Blumentál (0080). Trojka (Račianske mýto > Blumentál > Americké nám.) sa stretne s deviatkou (Vysoká/STU > Blumentál > Krížna) a opačne; len v zastávke Blumentál, tolerancia 20 s. Prvé pravidlo: spojenie koľají pri Kráľovskom údolí (v118). Ďalšie miesta sa pridajú podľa praxe (zoznam VETVA / smerBlumental v stretnutia.js).

## v120
- Žiadosť o službu / Zmena služby: zjednodušený formulár. Namiesto Ľubovoľná/Ranná/Odpoludňajšia/Delená sú dva riadky zaškrtávacích políčok: Kedy (Ranná, Poobedná) a Aká (Špička, Celodenná); všetko zaškrtnuté alebo nič = je to jedno; Ranná + Poobedná + len Špička = delená. Striedač je políčko vedľa poľa Linka. Časy (Nástup po/Ukončenie do, pri Nechcem Nástup pred/Ukončenie po) a Poznámka ostávajú.

## v121
- Žiadosť o službu / Zmena služby: v bloku „Nechcem“ zrušené riadky Ranná/Poobedná a Špička/Celodenná (ostali časy, linka, Striedač); v bloku „Chcem“ ostali riadky bez nápisov „Kedy“ a „Aká“.

## v122
- Cestovné poriadky / Zastávkový: zrušená história „Naposledy“ (neukladá sa, starý záznam sa zmaže; Obľúbené ostávajú). Pri otvorenej zastávke je vľavo „‹ Späť“, ktoré vráti zoznam, z ktorého si zastávku otvoril (obľúbené / výsledky hľadania / zastávky v okolí). Zavretie okna vynuluje pole, výsledky aj otvorenú zastávku, takže sa vždy začína odznova.

## v123–v125
- Cestovné poriadky / Službový: popri písaní čísla kurzu je výber tromi kolieskami: Linka (v riadku ikona trakcie a číslo linky, električky, potom trolejbusy, potom autobusy) | Poradie (kurz) | Typ dňa (predvolene dnešný). Pod kolieskami riadok s kurzom a časom (napr. 20/3 · 7:06–23:14 · Nedeľa) a tlačidlo „Zobraziť“. Zoznam kurzov: `data/<priečinok>/OBEH/_zoznam.txt(.gz)`; vytvára ho `node tools/obehy-zoznam.mjs` (spustiť po každom `obehy-split.mjs` / pri novom grafikone). Trakcia podľa čísla linky: električky 1, 3, 4, 9; trolejbusy 32, 33, 40, 42, 44, 45, 47, 49, 60, 61, 71, 72 (konštanta TROLEJBUSY v cestovne-poriadky.js; v dátach grafikonu identifikátor trakcie nie je); ostatné autobusy.

## v126
- Trolejbusové linky doplnené do výberu kurzu (Službový CP).
- Zoznam trakcie liniek sa zhoduje so statickým GTFS (routes.txt, route_type 0 = električka, 11 = trolejbus, 3 = autobus); nočné trolejbusy N44, N47, N72 = linky 444, 447, 472.

## v128
- Hlavný kalendár: služby dňa sa načítajú pre celý mesiac (predtým mala bodku len už otvorená dňa). Pri čísle dňa je čiarka podľa stredu služby (priemer nástupu a ukončenia): pred 12:00 hore, 12:00–16:30 v strede, po 16:30 dole; deň s dvoma službami (delená) = dve malé čiarky hore a dole. Deň s neprítomnosťou ostáva s pôvodnou bodkou. Pravidlo je v samostatnom `js/funkcie/kalendar-znacky.js` (DpbKalZnacky), aby ho neskôr použil aj vlastný výber dátumu v oknách (Zmena stavu, Žiadosť o službu).

## v129
- Dátumy vo formulároch Zmeny stavu (Dovolenka/PN Od–Do, Ukončenie neprítomnosti) sa vyberajú vlastným kalendárom s čiarkami služieb (rovnaké ako v hlavnom kalendári). Do je pri PN nepovinné ("Bez konca"). Kód: `vyberDatumu`/`datumPole` v `js/funkcie/zmena-stavu.js` (?v=11).

## v130
- Reklamácia: „Chýbajúce hradenie“ len pri záložnom vozidle (944). Vozidlo: ak ich je viac, ukáže všetky čísla a pýta, ktoré je nesprávne; ak chýba, položka sa volá „Vozidlo (chýba)“ a pýta číslo. (`zmena-stavu.js` ?v=12)

## v131
- Box Výpravňa sa po rozbalení sám zbalí po 3 s (už sa nepamätá otvorený stav).
- Pre iný deň než dnes ukazuje Výpravňa pevne Denná / Nočná (KR, TR); „Teraz / Nasleduje“ len pre dnešok (`DpbVypravna.dennaNocna`).
- Karta výpravcu: dolný pás ukazuje, kto je počas jeho služby na sedavej zálohe (TR = E1, KR = E2), pri viacerých ľuďoch s časmi (`DpbVypravna.sedava`). Nasledovník výpravcu sa v dolnom páse už nezobrazuje.

## v132
- Sedavé zálohy sa presunuli z dolného pásu karty výpravcu do rozbaleného boxu Výpravňa (karta má znova nasledovníka). Ak mám v daný deň službu na výpravni, box ukáže obe výpravne (moju prvú): pri mojej len sedavé zálohy, pri druhej výpravcu tej istej zmeny aj sedavé zálohy – všetko v plnej dĺžke ich služby (`podrobne` v `vypravna-pas.js`, `DpbVypravna.sedava`).

## v133
- Rozbalený box Výpravňa ostáva 10 s a posledné 2 s pomaly zmizne (stmievanie, `.vyp-box.mizne`).

## v134 – veľkosť písma
- Nikde menej ako 15 px (CSS, inline štýly v JS aj v HTML); výnimky: spodné menu (10 px) a text pri logu. Dispečing (názov + číslo) 16 px na jednom riadku (pri 20 px sa nezmestil), vozidlo a jeho časy 20 px, časy vozidla bez úvodnej nuly (4:04 namiesto 04:04).

## v135
- Koho stretnem: miesto je len „Zastávka“ alebo „X – Y“; pod ním kurz, meno a vozidlo oddelené medzerami (bez slov „kurz“, „voz.“). Písmo v kolese 18 px.
- Grafikon a Hľadať: písmo 18 px (stĺpec času v grafikone 82 px, aby sa nezlieval s názvom).

## v136
- Bodky kariet dňa (`js/funkcie/karty-bodky.js`, ?v=1): ak je v dni viac kariet, na pravom okraji je stĺpec bodiek; zobrazená karta je červená, ťuk na bodku posunie zoznam na kartu.
- Časy „od – do“ v prestávkach, hradeniach, jazdách z pohotovosti a v zozname striedačov sú zarovnané podľa pomlčky (`zarovnajCas` v `karta-sluzby.js`, triedy `.cas-od/.cas-do`).

## v137 – náhľad hlásení
- Kým nie je server, každé hlásenie (Zmena stavu, Žiadosť o službu/zmenu služby, Reklamácia, Nahlásiť, nezabezpečená prestávka, Rezervovať v Burze) sa najprv zobrazí v okne „Hlásenie – náhľad“ s upraviteľným textom; až tlačidlo „Skopírovať / zdieľať“ ho skopíruje alebo otvorí zdieľanie. Jediné miesto: `odosli` v `zmena-stavu.js` (exportované ako `DpbZmenaStavu.ukaz`); texty sú v `spravaText` a v jednotlivých formulároch, v Burze v `rezervuj`.

## v138
- Burza: trasa „striedač X – striedač X“ sa píše len raz („striedač X“); pri rôznych miestach sa „striedač“ píše len na začiatku (`trasaText` v `burza.js`).

## v139
- Hlásenie „Žiadosť o službu z burzy“ už neobsahuje riadok Trasa.

## v140
- Text pri logu v hlavičke vrátený na pôvodných 11 px (omylom sa zväčšil v v134). Na displejoch ≤350 px sa dispečing zmestí na jeden riadok (názov 13 px, číslo 15 px). Zásada: písmo sa na malých displejoch nezmenšuje pod 15 px (okrem tohto dispečingu), appka sa prispôsobí zalamovaním.

## v141 – rozloženie na širokých displejoch
- Pri šírke okna ≥560 px (rozložená skladačka, tablet, počítač) je appka v stĺpci široký max. 480 px na stred, po stranách pozadie. `transform: translateZ(0)` na `body` drží pevné prvky (menu, okná, bodky) v stĺpci. Pod 560 px sa nič nemení.

## v142
- Bodky kariet nepočítajú riadky služieb z Burzy na karte Voľno (`.burza-row`), len skutočné karty dňa.

## v143 – kontrola odpočinku v Burze
- `js/data/odpocinok.js` (testy: `node tests/odpocinok.test.mjs`): presne na minúty, bez posúvania okien. Práca = všetky karty s časom (služba, striedač, 944, pohotovosť, výpravca) + vlastné aktívne rezervácie z burzy; neprítomnosť je odpočinok; čas bez dát sa berie ako voľný.
  - Denný odpočinok pred a po ponúkanej službe: ≥ 11 h v poriadku; 6–11 h sa služba ukáže s oranžovým upozornením „Skrátený odpočinok: pred X h Y min“; < 6 h (alebo prekrytie) = nie je v Burze.
  - Týždenný: 7 dní PRED nástupom (okno končí nástupom) aj 7 dní PO konci služby (okno začína koncom) musí obsahovať nepretržitý odpočinok ≥ 35 h (24 + 11). Odpočinok sa orezáva oknom.
- Zapojené v `dostupna()` v `burza.js` (`kontrolaOdpocinku`).
- Zatiaľ nekontrolované: čas jazdy 10 h/24 h a 48 h/týždeň (§ 26), prestávky (§ 27), limity skrátenia (3× týždenne, nie dva dni po sebe), rozdelený odpočinok.

## v144
- Burza: limity skrátenia denného odpočinku – skrátený odpočinok (6–11 h) najviac 3× v 7 po sebe idúcich dňoch a nie dva dni po sebe (skrátený odpočinok sa priraďuje ku dňu nástupu, ktorý po ňom nasleduje). Služba, ktorá by limit porušila, sa v Burze neukáže.
- Zatiaľ sa NEKONTROLUJE: náhrada skrátenia do konca nasledujúceho týždňa, čas jazdy (10 h/24 h, 48 h/týždeň – nie sú dáta), prestávky po 4 h jazdy, rozdelený odpočinok. Treba doplniť, keď budú dáta z databázy.

## v145 – delená služba v Burze
- Burza už neschová službu len preto, že vodič má v ten deň inú službu: ďalšia časť v ten istý deň = delená zmena (ukáže sa „Delená služba (v ten deň máš aj inú časť)“). Odpočinok (11/6 h, limity skrátenia, týždenných 35 h) sa počíta pred celou zmenou a po nej; prekrytie je zakázané; neprítomnosť (dovolenka, PN) v ten deň službu stále schová. Rozpätie delenej služby ani minimálna pauza medzi časťami sa zatiaľ nekontrolujú (podľa Romana to sedí).

## v146
- Burza už pri službe v ten istý deň neukazuje žiadny text o delenej službe (logika ostáva, `s.delena` sa len nezobrazuje). Služba sa ako delená bude brať až pri prepočtoch pridelenej služby (výkaz): napr. po 5-hodinovej ranej špičke si vodič vezme 6-hodinovú inú službu a na výkaze sa tvári ako delená. Minimálna pauza medzi časťami sa nekontroluje.

## v147 – predvyplnenie Žiadosti o službu
- Pri voľnom dni (bez služby) sa v Žiadosti o službu v skupine „Chcem“ predvyplní „Nástup po“ (koniec poslednej práce pred dňom + 6 h), „Ukončenie do“ (nástup prvej práce po dni − 6 h) a Ranná/Poobedná (nástup po ≥ 10:00 → Poobedná; ukončenie do ≤ 16:00 → Ranná). Počíta sa s minimálnym skráteným odpočinkom 6 h (voľba Romana). Týždenných 35 h sa predvyplnenie netýka. Kód: `DpbOdpocinok.okno/praceVodica`, `ziadostSluzby` v `zmena-stavu.js`.

## v148 – predvyplnenie Žiadosti o službu aj podľa týždenného odpočinku 35 h
- Nová funkcia `DpbOdpocinok.okno2(prace, dateKey)`: okrem denného odpočinku (min. 6 h) overuje presne na minútu aj týždenných 35 h (rovnako ako kontrola v Burze, cez `skontroluj`). Vracia `plny` (celý rozsah je v poriadku), `nemozne` (v ten deň sa služba nedá), alebo obmedzenie `ranna.do` / `poobedna.od`.
- Formulár: pri „nemožnom" dni sa nič nepredvyplní a zobrazí sa poznámka; pri obmedzení sa predvyplní najneskorší koniec (ranná) alebo najskorší nástup (poobedná); ak sú možné obe, uvedie sa oboje v poznámke.
- Stále sa nekontroluje: náhrada skrátenia denného odpočinku, čas jazdy, prestávky, delený odpočinok.
- Testy: `node tests/odpocinok.test.mjs`.

## v149 – oprava: striedač sa počíta ako práca v kontrole odpočinku
- Chyba: karty STRIEDAČ nemajú `od_min`/`do_min` (len texty `od`/`do`), preto ich kontrola odpočinku vôbec nebrala. V Burze sa preto ponúkali služby prekrývajúce sa so striedačom (napr. 2.11. striedač 17:30–19:50 a poobedné služby).
- Nová funkcia `DpbOdpocinok.casKarty(k)` (čas z minút, inak z textu; cez polnoc +24 h). `praceVodica` ju používa a `kontrolaOdpocinku` v `burza.js` teraz berie prácu z `praceVodica` (jedno miesto výpočtu).
- `okno2` hľadá po minútach (podmienky nie sú monotónne) a pri zvláštnom prípade ponúkne „kratšiu službu napr. od–do“.
- Simulácia na reálnych dátach (8135 voľných dní vodičov, sep–okt 2026): 6836 plne voľných, 1196 obmedzených, 103 nemožných, 0 nezhôd s nezávislou kontrolou.
- Testy: striedač je práca, prekrytie sa odmietne, ranná špička + popoludňajší striedač (delená) prejde.

## v150 – odkaz do Burzy pod kartou dňa
- Ak má deň službu a v budúcnosti sú z burzy možné ďalšie služby (po kontrole odpočinku), pod kartou sa zobrazí riadok „Z burzy sa dá pridať: N služby ›“. Klik otvorí Burzu s filtrom daného dňa.
- Karta Voľno: odznak „N služby v burze“ už neotvára vložený zoznam, ale tiež Burzu s filtrom dňa (rovnaké správanie).
- Návrat: tlačidlo „← Späť na kartu dňa“ v Burze vráti na ten istý deň v Dnes. Kód: `otvorBurzuPreDen` v `hlavna.js`, `.burza-link-row` v `style.css`.

## v151 – karta Voľno: rovnaký riadok do Burzy ako pri iných kartách
- Červený odznak „N služby v burze“ vo vnútri karty Voľno nahradil rovnaký riadok pod kartou „Z burzy sa dá pridať: N služby ›“ ako pri dni so službou. Klik otvorí Burzu s filtrom dňa (návrat „← Späť na kartu dňa“).

## v152 – denný výkon najviac 12 h
- Kontrola odpočinku (`skontroluj`) odmietne službu, ak by súčet práce v deň nástupu (vrátane delených častí) presiahol 12 h. Pravidlo: Zákonník práce § 87 ods. 4 („pracovný čas v priebehu 24 hodín nesmie presiahnuť 12 hodín“); v zákone 462/2007 (§ 25–28) taký limit nie je, tam je len čas jazdy 10 h/24 h. Počíta sa čas od–do, prestávky sa neodpočítavajú (konzervatívne).
- Predvyplnenie Žiadosti o službu limit 12 h nepoužíva ako časové okno (je to dĺžka služby), len pripomenie „služba najviac 12 h“.
- Zatiaľ sa nekontroluje: pohyblivé 24 h okno cez polnoc (počíta sa podľa dňa nástupu), čas jazdy, prestávky.
- Testy: hranica presne 12 h, 12 h 1 min, delená 5+8 h, delená 5+6 h; staré testy upravené na realistické zmeny ≤ 12 h.

## v153 – miesta v Burze, filter dňa
- Detail služby v Burze: bežná služba ukazuje miesto nástupu aj ukončenia vždy („Dp. Krasňany – Dp. Krasňany“, aj keď sú rovnaké); len pohotovosť (Dispozičný vodič, sedavá záloha) ukazuje jedno miesto (nástup). Oprava omylom zrušeného zobrazenia z v146.
- Burza otvorená z karty dňa: filter je iba na deň; tlačidlo „Všetky“ sa nezobrazuje, „Späť“ sa volá „← Späť na dátum“.

## v154 – striedač: len hradenia v rozsahu služby vodiča
- Karta Striedač ukazuje len tie hradenia (kurzy), ktoré sa prekrývajú s časom služby daného vodiča. Predtým sa vzal celý zoznam „slotu“ z DPB_STATIC (napr. pri Eve Janícsekovej 8:44–9:20 sa ukázali 3 hradenia namiesto jedného, 3/2). Ak by po filtrovaní nezostalo nič, ukáže sa celý zoznam (poistka).
- Overené na reálnych dátach: z 1462 kariet Striedač sa 1323 nezmenilo, 43 sa skrátilo, žiadna nezostala prázdna. Konečný (6:56–12:15) si ponechá všetky tri. Všetky testy prešli.

## v155 – pohotovosť: odrobené úseky ako samostatné karty
- Karta Dispozičný vodič (obálka pohotovosti) zostáva; služby, ktoré z pohotovosti odrobil, sa už nevnárajú do jej zoznamu (zásky), ale sú samostatné karty (ako Striedač), s miestom z dát/grafikonu (napr. 1/8: Dp. Trnávka – Dp. Trnávka). Ak služba presahuje koniec obálky, pohotovosť sa končí nástupom služby a presah je samostatná karta (to už tak fungovalo).
- Výkon: čo je v obálke pohotovosti, nie je samostatný výkon; do limitu 12 h sa počíta zjednotenie prekrývajúcich sa intervalov (`skontroluj`). Presah mimo obálky sa pripočíta.
- Koho stretne: bez zmeny (po skončení sa nestretne nikto).
- Testy: `karta-z-useku` upravený, nové testy obálky v `odpocinok.test.mjs`.

## v156 – hradenia na karte 944 sa rozbaľujú
- Riadok hradenia na karte Záložné vozidlo (944) má šípku ako pri Striedači; po rozbalení je „odkiaľ – kam“ (stanice úseku z dát výpravy, 285/285 hradení ich má) a meno vodiča, ktorý mal ten kurz v tom čase (viac mien pod sebou, ak ich je viac; „—“ ak nikto). Klik na číslo kurzu stále otvorí grafikon.
- Model: `hradenia[].stan_od/stan_do` v `karta-z-useku.js`; zobrazenie v `buildStrList` (`karta-sluzby.js`), `.str-detail.hrad` v `style.css`.

## v157 – miesto na kartách podľa grafikonu pri časti služby
- Export výpravy má stanice (STANSMERVYJEZD/PRIJEZD) pre celý plánovaný úsek. Ak vodič robil len časť, miesto nesedelo s časom karty (napr. 3/39 7:16–8:26 ukazovalo Dp. Krasňany).
- Pravidlo (každý koniec zvlášť): skutočný začiatok = plánovaný nástup → miesto nástupu z dát služby; inak sa dohľadá z grafikonu v čase karty. Skutočný koniec = plánovaný koniec → miesto ukončenia z dát služby; inak z grafikonu. Platí pre karty služieb (aj tie, čo robil dispozičný vodič) a pre hradenia na karte 944.
- Grafikon: nová `DpbStretnutia.miesto(kurz, dátum, od, do)` – zastávka, v ktorej/pri ktorej (±2,5 min) kurz v čase je; bez zastávky v blízkosti sa použije miesto z dát. Zobrazenie „Dp.“ ako v dátach.
- Príznaky `graf_od`/`graf_do` v kartách (`karta-z-useku.js`). Overené: z 524 riadkov (1.9., 14.10.) je 45 čiastočných.

## v158 – vzhľad kariet
- Miesto „odkiaľ – kam“ na kartách služby a 944 sa vždy píše na dva riadky: prvý miesto nástupu, druhý miesto ukončenia (bez pomlčiek). Rovnako v rozbalenom hradení na karte 944.
- Miesto pri Striedačovi (zastávka) má veľkosť 18 px ako miesto pri Dispozičnom vodičovi (predtým 15 px).
- Karta Voľno už neukazuje typ dňa (Sobota, Pracovný deň…).
- Zobrazenie aktuálneho dňa (dnes): názov dňa aj dátum sú zelené a najtučnejšie (`.je-dnes`, v tmavom režime svetlejšia zelená).

## v159 – tmavý režim: stavové hlásenia (toast)
- Toast („Žiadosť odoslaná“, „Pripravuje sa“…) mal pozadie `--text-1` a biele písmo; v tmavom režime je `--text-1` svetlá, takže bolo biele na bielom. V tmavom režime má teraz tmavo-šedé pozadie a svetlé písmo (v svetlom beze zmeny). Automatická kontrola kontrastu na obrazovkách Dnes, Burza a Profil v tmavom režime nenašla ďalší problém.

## v160 – gesto „späť“
`js/funkcie/spat.js`: gesto/tlačidlo späť v telefóne už neukončí appku, ale zavrie hornú vrstvu (okná → žiadosť → grafikon → cestovné poriadky → kalendár → notifikácie → filter burzy → obrazovka iná než Dnes). Na hlavnej obrazovke prvé potiahnutie ukáže upozornenie, druhé do 2 s appku ukončí. Tlačidlá „späť“ na obrazovke zatiaľ ostali (o odstránení sa rozhodneme spolu).

### v161
Z Burzy (otvorenej z karty dňa) zmizlo tlačidlo „← Späť na dátum“; vráti ju gesto/tlačidlo späť (`Burza.zrusFilter`).

### v162
Kolotoč ikon dopravy (`ikony-dopravy.js`): na iPhone (Safari) miznú vozidlá, lebo sa počas animácie menila výška prvku s maskou. Teraz majú ikony pevnú veľkosť a menia sa len cez `transform: scale` (GPU), čo Safari prekresľuje spoľahlivo.

### v163
Kolotoč ikon dopravy sa kreslí do `<canvas>` namiesto CSS masiek (iPhone/Safari ich pri animácii zahadzoval). Rovnaký vzhľad, podklad v farbe pozadia, ikona červená s priehľadnosťou podľa hĺbky.

### v164
- Cestovné poriadky → Službový: hore rolety (linka / poradie / typ), pod nimi ručné zadanie. Do poľa ide aj `linka/poradie` (napr. `1/3`), typ dňa sa vtedy berie dnešný.
- Zobrazenie kurzu: hlavička spoja je tmavosivá a čierna je len hlavička spoja, ktorý práve ide; aktuálny riadok („Teraz“) má červený rámik, farba nezmenená.

### v165
Zastávkový poriadok: na konci každého odchodu šípka › – po ťuknutí na riadok sa pod ním rozbalí meno vodiča kurzu v danom čase (SLUŽBA alebo STRIEDAČ z výpravy, len dnešný deň). Políčko „Vodiči“ v hlavičke rozbalí všetkých naraz. Rozbalenie prežije obnovu zoznamu.

### v166 (úpravy podľa auditu ovládania)
- ⋮ na kartách má dotykovú plochu 44 px (vzhľad rovnaký, bez popisov).
- Spodné menu: písmo 12 px, „Ces. poriadky“ → „Poriadky“ (nezalamuje sa).
- Burza: „Odpočinok iba: pred 6 h 16 min“, tmavší odtieň pre čitateľnosť, nezalomiteľné medzery v čase.
- Cestovné poriadky sú súčasťou appky: spodné menu ostáva viditeľné, vlastné „Zavrieť“ zmizlo; iná záložka okno zatvorí.
- Pole hľadania (Hľadať) bez červeného rámika pri písaní.
- Profil: tlačidlá a prepínač rovnako vysoké (48 px), čitateľnejšia červená.
- Voľno má rovnaké písmo ako názov kurzu (linka/poradie).
- Zoznam mesiaca: dátum víkendu/sviatku má lepší kontrast.
- Kalendár: swipe vľavo/vpravo prepína mesiace (v zozname mesiaca to už fungovalo).

### v167
Kurz s písmenovým predponom (napr. `NED/1ž`) sa čistí rovnako ako číselné kurzy: koncovky `ž`, `str`, `JME`, `JD` sa orežú → `NED/1`. Predtým `cleanKurz` v `os-vodica.js` a `adapter-csv.js` preskočil reťazce bez tvaru číslo/číslo.

### v168
Cestovné poriadky: po zatvorení sa okno vráti na záložku Zastávkový. Predtým ostal zobrazený Službový panel bez roliet (rolety sa pri zatvorení rušia), takže pri ďalšom otvorení z menu bol prázdny.

import "../js/data/odpocinok.js";
const O = globalThis.DpbOdpocinok;
const h = (x) => x * 60, d = (n, hh = 0) => n * 1440 + hh * 60;
let f = 0; const t = (n, c) => { if (!c) { f++; console.log("CHYBA:", n); } else console.log("ok:", n); };
// bez inej práce: ok
t("prázdny kalendár", O.skontroluj([], { od: d(10, 6), do: d(10, 14) }).ok);
// odpočinok 12 h pred, 12 h po: ok bez skrátenia
let r = O.skontroluj([{ od: d(9, 6), do: d(9, 14) - h(0) - h(4) }, { od: d(11, 2), do: d(11, 10) }], { od: d(10, 6), do: d(10, 14) });
t("12h pred a po -> ok, nie skrátený", r.ok && !r.skrateny);
// 8 h pred -> skrátený
r = O.skontroluj([{ od: d(9, 10), do: d(9, 22) }], { od: d(10, 6), do: d(10, 12) });
t("8h pred -> skrátený", r.ok && r.skrateny && r.skrateny.pred === h(8));
// 5 h 59 min pred -> nie
r = O.skontroluj([{ od: d(9, 6), do: d(10, 0) }], { od: d(10, 5, 0) + 59, do: d(10, 12) });
t("5:59 pred -> nie", !r.ok);
// presne 6 h -> skrátený ok
r = O.skontroluj([{ od: d(9, 12), do: d(10, 0) }], { od: d(10, 6), do: d(10, 12) });
t("presne 6h -> ok skrátený", r.ok && r.skrateny);
// 7 dní práce po sebe (každý deň 6–14) + kandidát 8. deň -> nie (nikde 35 h)
let pr = []; for (let i = 0; i < 7; i++) pr.push({ od: d(i, 6), do: d(i, 14) });
r = O.skontroluj(pr, { od: d(7, 6), do: d(7, 14) });
t("8. deň po sebe bez 35h voľna -> nie", !r.ok);
// 6 dní práce + kandidát 7. deň: v okne 168 h od 0:00 d0 do d7 0:00 je len deň 6 voľný... 
pr = []; for (let i = 0; i < 6; i++) pr.push({ od: d(i, 6), do: d(i, 14) });
r = O.skontroluj(pr, { od: d(6, 6), do: d(6, 14) });
t("7 dní po sebe -> nie (okno bez 35h)", !r.ok);
// 5 dní práce, potom 2 voľné, potom kandidát: ok
pr = []; for (let i = 0; i < 5; i++) pr.push({ od: d(i, 6), do: d(i, 14) });
r = O.skontroluj(pr, { od: d(7, 6), do: d(7, 14) });
t("5 dní + 2 voľné + kandidát -> ok", r.ok);
// presná hranica 35 h: týždenný cyklus 133 h práce (nepretržite) + 35 h voľna
const C = 10020; let cyk = []; for (let k = 0; k < 4; k++) for (let i = 0; i < 6; i++) cyk.push({ od: k * C + i * 1440, do: k * C + i * 1440 + 720 });
r = O.skontroluj(cyk, { od: 4 * C, do: 4 * C + 720 });
t("cyklus s voľnom presne 35h -> ok", r.ok);
r = O.skontroluj(cyk, { od: 4 * C - 1, do: 4 * C + 719 });
t("voľno 34:59 -> nie", !r.ok);
// limity skrátenia: služby 6–14 každý deň s 8 h odpočinkom (nástup 22:00-ish nie – použijeme služby 0:00–16:00, nástup 0:00 -> odpočinok 8 h)
const kr = (n) => ({ od: d(n, 0), do: d(n, 16) });
// dni 0,2,4 majú skrátený odpočinok pred sebou (8 h od predošlej), ale medzi nimi je 24 h voľna -> 2 dni po sebe nie
let A = [{ od: d(0, 0), do: d(0, 16) }, { od: d(1, 0), do: d(1, 16) }];
r = O.skontroluj(A, { od: d(2, 0), do: d(2, 12) });
t("dva dni po sebe skrátený odpočinok -> nie", !r.ok && /dva dni/.test(r.dovod));
// každý druhý deň skrátený: dni 1,3,5 skrátené, štvrtý by bol 7 -> 4. v týždni nie
A = [{ od: d(0, 0), do: d(0, 16) }, { od: d(1, 0), do: d(1, 16) }].map(x => x);
// konštrukcia: práca 0:00-16:00 dni 0, skrátené nástupy dní 1, 3, 5 (8 h odpočinok), medzi nimi 1 deň voľna
const S = [[0, 0, 16], [1, 0, 8], [2, 16, 23], [3, 7, 12], [4, 20, 23], [5, 6, 10], [6, 20, 23]].map(([n, a, b]) => ({ od: d(n, a), do: d(n, b) }));
r = O.skontroluj(S, { od: d(7, 7), do: d(7, 12) });
t("4. skrátený odpočinok v 7 dňoch -> nie", !r.ok && /3 skrátené/.test(r.dovod));
r = O.skontroluj(S.slice(0, 6), { od: d(6, 20), do: d(6, 23) });
t("3. skrátený odpočinok (dni 1,3,5) sa ešte pripúšťa (kandidát bez skrátenia)", r.ok || !/skrát/.test(r.dovod));
// delená služba: ráno 4:00–9:00 už má, ponuka 14:00–19:00 v ten istý deň -> ok (odpočinok pred 4:00 a po 19:00)
r = O.skontroluj([{ od: d(5, 4), do: d(5, 9) }], { od: d(5, 14), do: d(5, 19) });
t("delená: ranná špička + poobedná v ten deň -> ok, delena", r.ok && r.delena);
// delená, ale predošlý deň končí o 22:00 -> odpočinok pred 4:00 je 6 h -> skrátený
r = O.skontroluj([{ od: d(5, 4), do: d(5, 9) }, { od: d(4, 14), do: d(4, 22) }], { od: d(5, 14), do: d(5, 19) });
t("delená: odpočinok pred celou zmenou 6h -> skrátený", r.ok && r.skrateny && r.skrateny.pred === h(6));
// prekrytie v ten istý deň -> nie
r = O.skontroluj([{ od: d(5, 4), do: d(5, 15) }], { od: d(5, 14), do: d(5, 19) });
t("prekrytie -> nie", !r.ok);
// poobedná 14:00–21:00 už je, ponuka ranná špička 5:00–7:30 ten istý deň; predošlý deň končil 13:00 -> odpočinok 16 h
r = O.skontroluj([{ od: d(5, 14), do: d(5, 21) }, { od: d(4, 6), do: d(4, 13) }], { od: d(5, 5), do: d(5, 7, 0) + 30 });
t("poobedná + ranná špička ten istý deň -> ok", r.ok && r.delena && !r.skrateny);
// to isté, ale predošlý deň končil 21:00 -> odpočinok pred 5:00 je 8 h -> skrátený (ale povolený)
r = O.skontroluj([{ od: d(5, 14), do: d(5, 21) }, { od: d(4, 14), do: d(4, 21) }], { od: d(5, 5), do: d(5, 7, 0) + 30 });
t("poobedná + ranná, odpočinok pred 5:00 je 8 h -> skrátený ok", r.ok && r.skrateny && r.skrateny.pred === h(8));
// odpočinok pred 5:00 len 5 h -> nie
r = O.skontroluj([{ od: d(5, 14), do: d(5, 21) }, { od: d(4, 14), do: d(5, 0) }], { od: d(5, 5), do: d(5, 7, 0) + 30 });
t("odpočinok pred prvým nástupom 5h -> nie", !r.ok);
// okno2: 5 dní po sebe 6-14 (dni 0..4), potom dni 5,6 voľné a opäť práca 6-14 od dňa 7 až 11
const K = i => new Date(Date.UTC(2026, 0, 5 + i)).toISOString().slice(0, 10);
let T = []; for (let i = 0; i < 5; i++) T.push({ od: O.abs(K(i), 6 * 60), do: O.abs(K(i), 14 * 60) });
for (let i = 7; i < 12; i++) T.push({ od: O.abs(K(i), 6 * 60), do: O.abs(K(i), 14 * 60) });
let w5 = O.okno2(T, K(5)), w6 = O.okno2(T, K(6));
console.log("(info) d5", JSON.stringify(w5), "d6", JSON.stringify(w6));
t("okno2: sobota po piatku s týždenným odpočinkom je plne možná alebo obmedzená, nie zmätok", typeof w5.nemozne === "boolean");
// hustý týždeň: 6 dní po sebe 6-14 a siedmy deň voľný len 1 deň -> druhý voľný deň nemožný ak by ostala 35 h len raz
let H = []; for (let i = 0; i < 6; i++) H.push({ od: O.abs(K(i), 6 * 60), do: O.abs(K(i), 14 * 60) });
let wh = O.okno2(H, K(6));
console.log("(info) hustý", JSON.stringify(wh));
t("okno2: 6 dní práce + voľný 7. deň: služba tam by zničila týždenný odpočinok", wh.plny === false);
// STRIEDAČ nemá od_min/do_min, len texty od/do: musí sa počítať ako práca
const M = { "1": [{ datum: "2026-11-02", karty: [{ vzor: "STRIEDAČ", kurz: "3/45", od: "17:30", do: "19:50" }] }] };
const PM = O.praceVodica(M, "1");
t("striedač sa berie ako práca", PM.length === 1 && PM[0].do - PM[0].od === 140);
t("burza: služba 13:32–23:49 sa s striedačom prekrýva -> nie", !O.skontroluj(PM, { od: O.abs("2026-11-02", 13 * 60 + 32), do: O.abs("2026-11-02", 23 * 60 + 49) }).ok);
t("burza: služba 16:29–18:57 sa prekrýva -> nie", !O.skontroluj(PM, { od: O.abs("2026-11-02", 16 * 60 + 29), do: O.abs("2026-11-02", 18 * 60 + 57) }).ok);
t("burza: ranná 5:29–9:10 + striedač popoludní (delená) -> ok", O.skontroluj(PM, { od: O.abs("2026-11-02", 5 * 60 + 29), do: O.abs("2026-11-02", 9 * 60 + 10) }).ok);
// 12 h práce za 24 h
{ const D = "2026-11-10", A = (h, m = 0) => O.abs(D, h * 60 + m);
  t("12 h presne -> ok", O.skontroluj([], { od: A(6), do: A(18) }).ok);
  t("12 h 1 min -> nie", !O.skontroluj([], { od: A(6), do: A(18, 1) }).ok);
  t("delená 5 h + 8 h = 13 h -> nie", !O.skontroluj([{ od: A(5), do: A(10) }], { od: A(15), do: A(23) }).ok);
  t("delená 5 h + 6 h = 11 h -> ok", O.skontroluj([{ od: A(5), do: A(10) }], { od: A(15), do: A(21) }).ok);
  t("dve časti 7 h + 6 h v ten deň = 13 h -> nie", !O.skontroluj([{ od: A(4), do: A(11) }], { od: A(17), do: A(23) }).ok);
}
{ const w = O.okno2([], "2026-11-10"); t("okno2: prázdny deň je plný (12 h limit nie je časové okno)", w.plny);
  const D = "2026-11-10"; const q = O.okno2([{ od: O.abs("2026-11-09", 12 * 60), do: O.abs("2026-11-10", 0) }], D);
  t("okno2: nástup po 6:00 aj keď okno > 12 h", q.nastupPo === 360 && q.plny); }
// obálka pohotovosti: služba vnútri nie je samostatný výkon (počíta sa zjednotenie), presah sa pripočíta
{ const D = "2026-11-10", A = (h, m = 0) => O.abs(D, h * 60 + m);
  const P = [{ od: A(3, 45), do: A(11, 45) }, { od: A(8, 44), do: A(9, 20) }];
  t("obálka 8 h + služba vnútri + ďalšia časť 4 h = 12 h -> ok", O.skontroluj(P, { od: A(15), do: A(19) }).dovod !== "viac ako 12 h práce za deň");
  t("obálka 8 h + služba vnútri + ďalšia časť 4 h 30 min = 12 h 30 min -> nie", O.skontroluj(P, { od: A(15), do: A(19, 30) }).dovod === "viac ako 12 h práce za deň");
  const P2 = [{ od: A(3, 45), do: A(10) }, { od: A(10), do: A(13) }];
  t("presah: pohotovosť do 10:00 + služba 10:00–13:00 = 9 h 15 min, ďalšia 3 h = 12 h 15 min -> nie", O.skontroluj(P2, { od: A(16), do: A(19) }).dovod === "viac ako 12 h práce za deň");
}
console.log(f ? "NEPREŠLO " + f : "VŠETKO OK");
process.exit(f ? 1 : 0);

import test from "node:test";
import assert from "node:assert/strict";
import { nacitaj, cita } from "./pomocnik.mjs";

const { GrafikonParsery: G } = nacitaj("js/data/grafikon-parsery.js");
const jr = cita("data/20260216/1.JR");
const sm = cita("data/20260216/1.SM");
const cile = cita("data/20260216/CILE.CL");
const stanice = cita("data/20260216/STANICE.ZS");

test("extractObeh vráti riadky jedného obehu a skončí na ďalšom #", () => {
  const riadky = G.extractObeh(jr, "#001011");
  assert.ok(riadky.length > 10);
  assert.ok(riadky.every((r) => !r.startsWith("#")));
  assert.ok(riadky[0].startsWith("L001"));
});

test("neexistujúci obeh -> prázdny zoznam", () => {
  assert.equal(JSON.stringify(G.extractObeh(jr, "#999999")), "[]"); // JSON: objekty z vm majú iný prototyp
});

test("parseSpoje: prvý spoj má zastávky s časmi", () => {
  const spoje = G.parseSpoje(G.extractObeh(jr, "#001011"));
  assert.ok(spoje.length >= 1);
  assert.equal(spoje[0].linka, "L001");
  assert.equal(JSON.stringify(spoje[0].zastavky[0]), JSON.stringify({ kod: "091204", time: "4:21:00" }));
  assert.ok(spoje[0].zastavky.every((z) => z.kod && z.time));
});

test("parseKV: ciele a stanice mapujú kód na názov", () => {
  const ciele = G.parseKV(cile);
  assert.equal(ciele["002"], "21P Pri Sandbergu");
  assert.ok(Object.keys(G.parseKV(stanice)).length > 100);
});

test("parseSM: kľúč linka_smer -> kód cieľa", () => {
  const mapa = G.parseSM(sm);
  const kluce = Object.keys(mapa);
  assert.ok(kluce.length > 0);
  assert.match(kluce[0], /^L\d+_S\d+$/);
});

// Pomocník pre testy: načíta klasické skripty appky do izolovaného "okna" bez prehliadača.
import vm from "node:vm";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

export const KOREN = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

export function nacitaj(...subory) {
  const okno = {
    console,
    TextDecoder,
    setTimeout,
    clearTimeout,
    document: { getElementById: () => null, querySelectorAll: () => [] },
  };
  okno.window = okno;
  vm.createContext(okno);
  for (const s of subory) {
    vm.runInContext(fs.readFileSync(path.join(KOREN, s), "utf8"), okno, { filename: s });
  }
  return okno;
}

export function cita(rel, kodovanie = "windows-1250") {
  return new TextDecoder(kodovanie).decode(fs.readFileSync(path.join(KOREN, rel)));
}

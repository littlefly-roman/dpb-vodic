import test from "node:test";
import assert from "node:assert/strict";
import { nacitaj } from "./pomocnik.mjs";

const w = nacitaj("js/data/cisti-riadky.js", "js/data/ciselnik-stavov.js", "js/data/os-vodica.js", "js/data/karta-z-useku.js", "js/data/adapter-csv.js");

const hlavicka = [
  "CISLO_VYPRAVENKY", "RADEK", "PORADI", "DATUM", "CISLOTURNUSU", "NASTUP", "VYJEZD", "PRIJEZD", "KONEC",
  "CISLO_SLUZBY", "LINKAKURZ", "RIDIC_CISLO", "RIDIC_PP", "RIDIC_PRIJMENI", "RIDIC_JMENO",
  "SKUTVYJEZD", "SKUTPRIJEZD", "SKUTNASTUP", "SKUTKONEC", "STAVTURNUSU", "CISVOZU1", "VUZ1OD", "VUZ1DO",
].join(";");
const riadok = (rid, meno, priezvisko, vyp = "1", vozidlo = "7429", opravil = "") =>
  [
    vyp, "1", "0", "2026-09-17", "E645", "2026-09-17 13:29:00.000", "2026-09-17 13:37:30.000",
    "2026-09-17 23:16:15.000", "2026-09-17 23:36:00.000", "100", "1/01", rid, "1", priezvisko, meno,
    "2026-09-17 13:29:00.000", "2026-09-17 23:36:00.000", "2026-09-17 13:29:00.000", "2026-09-17 23:36:00.000",
    "0", vozidlo, "2026-09-17 13:29:00.000", "2026-09-17 23:36:00.000",
  ].join(";");

test("CSV s vymyslenými vodičmi sa prevedie na vodičov a služby", () => {
  const csv = [hlavicka, riadok("90001", "Testovací", "Jeden"), riadok("90002", "Druhý", "Test", "2")].join("\n");
  const raw = w._csv2raw(csv);
  assert.ok(raw.drivers && raw.models);
  assert.equal(Object.keys(raw.drivers).length, 2);
  assert.ok(Object.values(raw.drivers).some((m) => m.includes("Jeden")));
  const dni = raw.models["90001"];
  assert.equal(dni[0].datum, "2026-09-17");
});

test("Viac verzií toho istého riadku: platí najnovšia (OPRAVILCAS)", () => {
  const h = hlavicka + ";OPRAVILCAS";
  const r = (vozidlo, cas) => riadok("90001", "Testovací", "Jeden", "5", vozidlo) + ";" + cas;
  const csv = [h, r("", "2026-09-10 08:00:00.000"), r("7435", "2026-09-16 00:20:00.000"), r("", "2026-09-01 08:00:00.000")].join("\n");
  const raw = w._csv2raw(csv);
  const dni = raw.models["90001"];
  assert.equal(dni.length, 1);
  assert.ok(JSON.stringify(dni[0]).includes("7435"));
});

test("Prekrývajúce sa služby jedného vodiča: platí neskôr upravený riadok", () => {
  const h = hlavicka + ";OPRAVILCAS";
  const stary = riadok("90001", "Testovací", "Jeden", "7", "7429") + ";2026-09-10 08:00:00.000";
  // druhý riadok: iná výpravenka, tá istá doba, novšia úprava, iný kurz
  const novy = riadok("90001", "Testovací", "Jeden", "8", "7430").replace(";1/01;", ";2/02;") + ";2026-09-16 08:00:00.000";
  const raw = w._csv2raw([h, stary, novy].join("\n"));
  const dni = JSON.stringify(raw.models["90001"]);
  assert.ok(dni.includes("2/2"));
  assert.ok(!dni.includes("1/1"));
});

test("Zácvik: vedúci vidí zacvičovaného, zacvičovaný vidí vedúceho", () => {
  const h = hlavicka + ";ZACVIK1;ZACVIK2;ZACVIK3;ZAC2OD;ZAC2DO";
  const r = (por, rid, meno, prie, voz) =>
    riadok(rid, meno, prie, "7", voz).replace(/^7;1;0;/, "7;1;" + por + ";") + ";;90002;;2026-09-17 13:29:00.000;2026-09-17 23:36:00.000";
  const csv = [h, r("0", "90001", "Marta", "Vedúca", "7540"), r("1", "90002", "Roman", "Nový", "5")].join("\n");
  const raw = w._csv2raw(csv);
  const ved = raw.models["90001"][0].karty[0];
  const noviciek = raw.models["90002"][0].karty[0];
  assert.equal(ved.zacvikVedie[0].rid, "90002");
  assert.equal(noviciek.zacvikSkym.rid, "90001");
  assert.ok(noviciek.zacvikSkym.meno.includes("Vedúca"));
});

test("Neprítomnosť má názov z firemného číselníka (19 = Vyžiadané voľno, 7 = Nemoc)", () => {
  const mk = (stav) => riadok("90001", "Test", "Jeden", "9").replace(";0;7429;", ";" + stav + ";7429;");
  const nazov = (stav) => w._csv2raw([hlavicka, mk(stav)].join("\n")).models["90001"][0].karty[0].popis;
  assert.equal(nazov("19"), "Vyžiadané voľno");
  assert.equal(nazov("7"), "Nemoc");
  assert.equal(nazov("999"), "kód 999");
});

test("Číselník stavov: slovenské názvy bez českých znakov a každý kód má povodný názov", () => {
  const k = w.DpbCiselnikStavov.kody;
  const kody = Object.keys(k);
  assert.ok(kody.length >= 60);
  for (const c of kody) {
    assert.ok(k[c].nazov && k[c].povodny, "kód " + c);
    assert.ok(!/[ěřůĚŘŮ]/.test(k[c].nazov), "český znak v názve kódu " + c + ": " + k[c].nazov);
  }
});

test("Etapa 3 krok 1: služba s plánovaným koncom po polnoci má minúty zo skutočných časov", () => {
  const h = hlavicka + ";NASTUP;KONEC";
  const r = riadok("90001", "Test", "Jeden", "9").replace("2026-09-17 13:29:00.000;2026-09-17 13:37:30.000", "2026-09-17 13:29:00.000;2026-09-17 13:37:30.000");
  const csv = [h, r + ";2026-09-17 13:37:00.000;2026-09-18 00:21:00.000"].join("\n");
  const k = w._csv2raw(csv).models["90001"][0].karty[0];
  assert.equal(k.vzor, "SLUŽBA");
  assert.equal(k.do_min - k.od_min, 607); // 13:29–23:36, nie +24 h
  assert.equal(k.kurz, "1/1");
});

test("Etapa 3 krok 1: karta neprítomnosti z úseku má kód a názov z číselníka", () => {
  const mk = riadok("90001", "Test", "Jeden", "9").replace(";0;7429;", ";1;7429;");
  const k = w._csv2raw([hlavicka, mk].join("\n")).models["90001"][0].karty[0];
  assert.equal(k.vzor, "NEPRÍTOMNOSŤ");
  assert.equal(k.kod, 1);
  assert.equal(k.popis, "Dovolenka čerpaná");
});

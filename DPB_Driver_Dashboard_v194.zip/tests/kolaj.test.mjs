import test from "node:test";
import assert from "node:assert/strict";
import { nacitaj } from "./pomocnik.mjs";

const w = nacitaj("js/data/kolaj_data.js");

test("výnimka podľa poradia a času odchodu (±90 s)", () => {
  assert.equal(w.getKolajInfo(3, 10, 1, "Južné mesto", "22:20", null), "vonkajšiu koľaj");
  assert.equal(w.getKolajInfo(3, 10, 1, "Južné mesto", "22:21", null), "vonkajšiu koľaj");
});

test("neznáma linka alebo cieľ -> null", () => {
  assert.equal(w.getKolajInfo(77, 1, 1, "Nikde", "10:00", null), null);
  assert.equal(w.getKolajInfo(3, 1, 1, "Neexistujúca konečná", "10:00", null), null);
});

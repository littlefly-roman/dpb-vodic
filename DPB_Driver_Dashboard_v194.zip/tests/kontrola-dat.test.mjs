import test from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";

// Aktuálny export: index, obehy a .gz musia presne zodpovedať zdrojovým .JR/.SM/CILE.CL
test("kontrola dát 20261003: index = zdroj, obehy = zdroj, .gz = originál", () => {
  const r = spawnSync("node", ["tools/kontrola-dat.mjs", "data/20261003"], { encoding: "utf8" });
  assert.equal(r.status, 0, r.stdout + r.stderr);
  assert.match(r.stdout, /KONTROLA PREŠLA/);
});

import test from "node:test";
import assert from "node:assert/strict";
import { nacitaj } from "./pomocnik.mjs";

const { Calendar } = nacitaj("js/core/kalendar.js");

test("typ dňa: pracovný deň, sobota, nedeľa", () => {
  assert.equal(Calendar.getDayType("2026-10-14"), 1); // streda
  assert.equal(Calendar.getDayType("2026-10-17"), 2); // sobota
  assert.equal(Calendar.getDayType("2026-10-18"), 3); // nedeľa
});

test("typ dňa: sviatok a prázdniny", () => {
  assert.equal(Calendar.getDayType("2026-01-01"), 3); // sviatok
  assert.equal(Calendar.getDayType("2026-04-06"), 3); // Veľkonočný pondelok
  assert.equal(Calendar.getDayType("2026-07-15"), 4); // pracovný deň počas prázdnin
});

test("1. a 15. september zostávajú pracovné dni (DPB ich jazdilo ako pracovné)", () => {
  assert.equal(Calendar.getDayType("2026-09-01"), 1);
  assert.equal(Calendar.getDayType("2026-09-15"), 1);
});

const priecinky = ["20260216", "20260829", "20260904", "20260904_corr", "20261003"];

test("výber priečinka grafikonu: najnovší platný k dňu", () => {
  assert.equal(Calendar.findDataFolder("2026-08-29", priecinky), "20260829");
  assert.equal(Calendar.findDataFolder("2026-09-03", priecinky), "20260829");
  assert.equal(Calendar.findDataFolder("2026-10-02", priecinky), "20260904_corr");
  assert.equal(Calendar.findDataFolder("2026-10-03", priecinky), "20261003");
  assert.equal(Calendar.findDataFolder("2027-01-01", priecinky), "20261003");
});

test("oprava grafikonu z toho istého dňa má prednosť pred pôvodným", () => {
  assert.equal(Calendar.findDataFolder("2026-09-04", priecinky), "20260904_corr");
});

test("dátum pred všetkými grafikonmi -> najstarší; prázdny zoznam -> null", () => {
  assert.equal(Calendar.findDataFolder("2025-01-01", priecinky), "20260216");
  assert.equal(Calendar.findDataFolder("2026-10-03", []), null);
  assert.equal(Calendar.findDataFolder("2026-10-03", null), null);
});

test("prázdniny jeseň/Vianoce 2026 podľa GTFS DPB", () => {
  assert.equal(Calendar.getDayType("2026-10-28"), 1); // streda – bežný pracovný deň
  assert.equal(Calendar.getDayType("2026-10-29"), 4);
  assert.equal(Calendar.getDayType("2026-10-30"), 4);
  assert.equal(Calendar.getDayType("2026-12-22"), 1); // GTFS: ešte pracovný deň
  assert.equal(Calendar.getDayType("2026-12-23"), 4);
  assert.equal(Calendar.getDayType("2026-12-24"), 3); // sviatok
  assert.equal(Calendar.getDayType("2026-12-28"), 4);
  assert.equal(Calendar.getDayType("2026-12-31"), 4);
});

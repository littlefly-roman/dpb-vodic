import test from "node:test";
import assert from "node:assert/strict";
import { nacitaj } from "./pomocnik.mjs";

const w = nacitaj("js/data/cisti-riadky.js", "js/data/ciselnik-stavov.js", "js/data/os-vodica.js", "js/data/volne-sluzby.js");
const V = w.DpbVolneSluzby;
const D = "2026-10-23";
const cas = (hm) => `${D} ${hm}:00.000`;
const r = (rad, kurz, trid, od, do_, rid, extra = {}) => ({
  CISLO_VYPRAVENKY: "1", CISLOTURNUSU: "E1", RADEK: String(rad), PORADI: "0", DATUM: D, ZOBRAZIT: "A", TYPDOPRAVY: "A",
  RIDIC_CISLO: rid, RIDIC_PRIJMENI: rid ? "Vodič" + rid : "", RIDIC_JMENO: "", LINKAKURZ: kurz, TRIDENI: String(trid),
  NASTUP: cas(od), KONEC: cas(do_), SKUTNASTUP: cas(od), SKUTKONEC: cas(do_), STAVTURNUSU: "0", ...extra,
});

test("voľná je len štandardná služba (linka/poradie) a pohotovosť, nie technické pozície", () => {
  const v = V.najdi([r(1, "3/16", 1, "06:00", "09:00", ""), r(2, "pohotovosť E2", 2, "13:00", "21:00", ""), r(3, "Technologická", 1, "05:00", "11:30", ""), r(4, "kurz E", 1, "06:00", "14:00", "")]);
  assert.equal(v.map((x) => x.kurz).join(","), "3/16,pohotovosť E2");
});
test("delená služba: ponúka sa len voľná časť", () => {
  const v = V.najdi([r(1, "3/16", 1, "06:00", "09:00", "5"), r(1, "3/16", 2, "14:00", "19:00", "")]);
  assert.equal(v.length, 1);
  assert.equal(v[0].cas, "14:00 – 19:00");
  assert.equal(v[0].trideni, 2);
});
test("obsadená služba a riadky so ZOBRAZIT=N sa nerátajú", () => {
  const v = V.najdi([r(1, "3/16", 1, "06:00", "09:00", "5"), r(2, "3/17", 1, "06:00", "09:00", "", { ZOBRAZIT: "N" })]);
  assert.equal(v.length, 0);
});
test("pôvodný vodič neprítomný a nikto ho nenahradil = voľná; nahradený = obsadená", () => {
  const abs = r(1, "3/16", 1, "06:00", "09:00", "5", { STAVTURNUSU: "13" });
  assert.equal(V.najdi([abs]).length, 1);
  const nahrada = r(1, "3/16", 1, "06:00", "09:00", "6", { PORADI: "1" });
  assert.equal(V.najdi([abs, nahrada]).length, 0);
});

test("pohotovosť sa v Burze volá Dispozičný vodič (Sedavá záloha) a E1/E2 majú miesto", () => {
  const v = V.najdi([r(1, "pohotovosť E1", 2, "13:00", "21:00", ""), r(2, "pohotovosť E2", 2, "13:00", "21:00", "")]);
  assert.equal(v[0].nazov, "Dispozičný vodič");
  assert.equal(v[0].podnazov, "Sedavá záloha");
  assert.equal(v.map((x) => x.stanicaOd).join(","), "Dp. Trnávka,Dp. Krasňany");
});

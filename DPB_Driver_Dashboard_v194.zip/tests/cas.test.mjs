import test from "node:test";
import assert from "node:assert/strict";
import { nacitaj } from "./pomocnik.mjs";

const { DpbCas } = nacitaj("js/core/cas.js");

test("formatDateKey", () => {
  assert.equal(DpbCas.formatDateKey(new Date(2026, 0, 5)), "2026-01-05");
  assert.equal(DpbCas.formatDateKey(new Date(2026, 11, 31)), "2026-12-31");
});

test("timeToSeconds", () => {
  assert.equal(DpbCas.timeToSeconds("4:21:00"), 4 * 3600 + 21 * 60);
  assert.equal(DpbCas.timeToSeconds("13:29"), 13 * 3600 + 29 * 60);
  assert.equal(DpbCas.timeToSeconds("0:30:15"), 30 * 60 + 15);
  assert.equal(DpbCas.timeToSeconds(""), 0);
  assert.equal(DpbCas.timeToSeconds(null), 0);
});

test("isSameDay a formatMonthTitle", () => {
  assert.equal(DpbCas.isSameDay(new Date(2026, 9, 18, 1), new Date(2026, 9, 18, 23)), true);
  assert.equal(DpbCas.isSameDay(new Date(2026, 9, 18), new Date(2026, 9, 19)), false);
  assert.match(DpbCas.formatMonthTitle(new Date(2026, 9, 18)), /^O/); // "Október 2026"
});

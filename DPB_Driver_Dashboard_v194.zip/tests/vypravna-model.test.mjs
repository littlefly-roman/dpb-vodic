import test from "node:test";
import assert from "node:assert/strict";
import { nacitaj } from "./pomocnik.mjs";

const V = nacitaj("js/data/vypravna-model.js").DpbVypravna;
const karta = (kurz, od, do_) => ({ vzor: "TRKR", kurz, od: "x", do: "y", od_min: od, do_min: do_ });
const models = {
  1: [{ datum: "2026-10-16", karty: [karta("nočnáKR", 1080, 1800)] }, { datum: "2026-10-17", karty: [karta("dennáKR", 360, 1080)] }],
  2: [{ datum: "2026-10-17", karty: [karta("nočnáKR", 1080, 1800), karta("dennáTR", 360, 1080)] }],
  3: [{ datum: "2026-10-18", karty: [karta("dennáKR", 360, 1080)] }],
};
const mena = { 1: "Anna", 2: "Boris", 3: "Cyril" };
const m = (a) => [...a].map((x) => x.meno);

test("cez deň je teraz denná a nasleduje nočná", () => {
  const r = V.kto(models, mena, "2026-10-17", 16 * 60 + 50);
  assert.deepEqual(m(r.KR.teraz), ["Anna"]);
  assert.deepEqual(m(r.KR.dalsi), ["Boris"]);
  assert.deepEqual(m(r.TR.teraz), ["Boris"]);
});
test("po polnoci je teraz nočná z predošlého dňa a nasleduje denná", () => {
  const r = V.kto(models, mena, "2026-10-17", 2 * 60);
  assert.deepEqual(m(r.KR.teraz), ["Anna"]);
  assert.deepEqual(m(r.KR.dalsi), ["Anna"]);
});
test("nasleduje aj zmena z ďalšieho dňa a prázdna skupina vráti prázdne zoznamy", () => {
  const r = V.kto(models, mena, "2026-10-17", 20 * 60);
  assert.deepEqual(m(r.KR.teraz), ["Boris"]);
  assert.deepEqual(m(r.KR.dalsi), ["Cyril"]);
  assert.deepEqual(m(r.TR.teraz), []);
  assert.deepEqual(m(r.TR.dalsi), []);
});

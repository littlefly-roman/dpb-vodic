import test from "node:test";
import assert from "node:assert/strict";
import { nacitaj } from "./pomocnik.mjs";

const { DpbCistiRiadky: C } = nacitaj("js/data/cisti-riadky.js");
const r = (v, rad, por, kurz, od, kon, opr, rid = "1") => ({
  CISLO_VYPRAVENKY: v, RADEK: rad, PORADI: por, LINKAKURZ: kurz, RIDIC_CISLO: rid, STAVTURNUSU: "0",
  DATUM: "2026-10-01", SKUTNASTUP: `2026-10-01 ${od}:00.000`, SKUTKONEC: `2026-10-01 ${kon}:00.000`, OPRAVILCAS: opr,
});

test("z viacerých verzií toho istého riadku platí najnovšia", () => {
  const out = C.cisti([r("5", "1", "0", "1/01", "10:00", "12:00", "2026-09-01"), r("5", "1", "0", "1/01", "10:00", "12:30", "2026-09-05")]);
  assert.equal(out.length, 1);
  assert.equal(out[0].SKUTKONEC.slice(11, 16), "12:30");
});

test("pri rovnakom čase úpravy platí neskorší riadok v súbore", () => {
  const out = C.cisti([r("5", "1", "0", "1/01", "10:00", "12:00", "2026-09-01"), r("5", "1", "0", "1/01", "10:00", "13:00", "2026-09-01")]);
  assert.equal(out[0].SKUTKONEC.slice(11, 16), "13:00");
});

test("prekryv dvoch služieb vodiča: starší riadok zmizne", () => {
  const out = C.cisti([r("5", "1", "0", "4/13", "13:01", "13:07", "2026-10-01"), r("6", "2", "0", "944/03", "12:58", "13:30", "2026-10-12")]);
  assert.equal(JSON.stringify(out.map((x) => x.LINKAKURZ)), JSON.stringify(["944/03"]));
});

test("dotyk úsekov o pár sekúnd nie je prekryv", () => {
  const a = r("5", "1", "0", "1/03", "14:47", "16:07", "2026-10-01");
  a.SKUTKONEC = "2026-10-01 16:07:30.000";
  const b = r("6", "2", "0", "944/06", "16:07", "16:15", "2026-10-12");
  assert.equal(C.cisti([a, b]).length, 2);
});

test("úseky toho istého kurzu sa nerušia", () => {
  const out = C.cisti([r("5", "1", "0", "944/06", "14:00", "16:00", "2026-10-01"), r("6", "2", "0", "944/06", "15:00", "17:00", "2026-10-12")]);
  assert.equal(out.length, 2);
});

test("koniec po polnoci sa nepovažuje za prekryv s ranými úsekmi", () => {
  const noc = r("5", "1", "0", "944/06", "18:17", "00:30", "2026-10-01");
  const rano = r("6", "2", "0", "1/03", "14:47", "16:07", "2026-10-12");
  assert.equal(C.cisti([noc, rano]).length, 2);
});

test("rovnaký riadok a poradie v inom turnuse sú dva rôzne záznamy", () => {
  const a = r("5", "1", "0", "1/01", "10:00", "12:00", "2026-09-01", "1"); a.CISLOTURNUSU = "1/01";
  const b = r("5", "1", "0", "2/01", "13:00", "15:00", "2026-09-01", "2"); b.CISLOTURNUSU = "2/01";
  assert.equal(C.najnovsieVerzie([a, b]).length, 2);
});

test("zmena turnusu pri úprave: platí len najnovšia verzia", () => {
  const a = r("5", "1", "0", "1/01", "10:00", "12:00", "2026-09-01"); a.CISLOTURNUSU = "1/01";
  const b = r("5", "1", "0", "1/01", "10:00", "12:00", "2026-09-05"); b.CISLOTURNUSU = "3/01";
  const out = C.cisti([a, b]);
  assert.equal(out.length, 1);
  assert.equal(out[0].CISLOTURNUSU, "3/01");
});

test("presná duplicita (rovnaký vodič, časy aj vozidlo, iné poradie): ostane nižšie poradie", () => {
  const a = r("5", "9", "0", "pohotovosť E2", "10:00", "17:30", "2026-10-01", "3926");
  const b = r("5", "9", "1", "pohotovosť E2", "10:00", "17:30", "2026-10-01", "3926");
  const out = C.cisti([b, a]);
  assert.equal(out.length, 1);
  assert.equal(out[0].PORADI, "0");
});

test("delená služba toho istého vodiča (rôzne časy) sa nerušia", () => {
  const a = r("5", "9", "0", "9/24str", "05:00", "09:00", "2026-10-01", "7");
  const b = r("5", "9", "1", "9/24str", "13:00", "17:00", "2026-10-01", "7");
  assert.equal(C.cisti([a, b]).length, 2);
});

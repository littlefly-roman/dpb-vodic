import test from "node:test";
import assert from "node:assert/strict";
import { nacitaj } from "./pomocnik.mjs";

const w = nacitaj("js/data/cisti-riadky.js", "js/data/ciselnik-stavov.js", "js/data/os-vodica.js");
const O = w.DpbOsVodica;
const D = "2026-10-17";
const cas = (hm, den = D) => `${den} ${hm}:00.000`;
// r(vyp, riadok, poradie, rid, meno, kurz, od, do, stav, vozidlo, extra)
const r = (vyp, rad, por, rid, meno, kurz, od, do_, stav = "0", voz = "7500", extra = {}) => ({
  CISLO_VYPRAVENKY: vyp, CISLOTURNUSU: "E1", RADEK: rad, PORADI: por, DATUM: D,
  RIDIC_CISLO: rid, RIDIC_PRIJMENI: meno, RIDIC_JMENO: "", LINKAKURZ: kurz, TRIDENI: "1",
  NASTUP: cas(od), KONEC: cas(do_), SKUTNASTUP: cas(od), SKUTKONEC: cas(do_),
  STAVTURNUSU: stav, CISVOZU1: stav === "0" ? voz : "", OPRAVILCAS: "2026-10-01 10:00:00.000", ...extra,
});
const den = (os, rid) => os.vodici[rid].dni[D];

test("náhrada: prítomný náhradník pri neprítomnom pôvodnom vodičovi, s dôvodom", () => {
  const os = O.postav([r("1", "8", "0", "10", "Dolník", "3/04", "12:26", "19:16", "1", ""), r("1", "8", "1", "11", "Sklenáková", "3/04", "12:26", "19:16")]);
  const sk = den(os, "11").useky[0];
  assert.equal(sk.nahrada[0].meno, "Dolník");
  assert.equal(sk.nahrada[0].dovod, "Dovolenka čerpaná");
  assert.equal(den(os, "10").useky[0].nahradil[0].meno, "Sklenáková");
  assert.equal(den(os, "10").useky[0].pritomny, false);
});

test("zácvik: rola vedúci/zacvičovaný podľa stĺpcov ZACVIK", () => {
  const z = { ZACVIK2: "20" };
  const os = O.postav([r("1", "31", "0", "13", "Mentusová", "3/26", "14:45", "23:55", "0", "7540", z), r("1", "31", "1", "20", "Nevedel", "3/26", "14:45", "23:55", "0", "5", z)]);
  const ved = den(os, "13").useky[0], zac = den(os, "20").useky[0];
  assert.equal(ved.zacvik.rola, "veduci");
  assert.equal(ved.zacvik.partneri[0].rid, "20");
  assert.equal(zac.zacvik.rola, "zacvicovany");
  assert.equal(zac.zacvik.partneri[0].rid, "13");
  assert.equal(os.problemy.length, 0);
});

test("dvaja prítomní naraz na bežnej službe bez zácviku a bez spoločného vozidla = nejasnosť", () => {
  const os = O.postav([r("1", "5", "0", "1", "A", "3/10", "08:00", "12:00", "0", "7501"), r("1", "5", "1", "2", "B", "3/10", "09:00", "13:00", "0", "7502")]);
  assert.equal(os.problemy.filter((p) => p.druh === "dvaja_pritomni_bez_zacviku").length, 1);
});

test("nadväzujúce úseky (odovzdanie) nie sú nejasnosť", () => {
  const os = O.postav([r("1", "5", "0", "1", "A", "3/10", "08:00", "12:00"), r("1", "5", "1", "2", "B", "3/10", "12:00", "16:00")]);
  assert.equal(os.problemy.length, 0);
});

test("školenie s viacerými ľuďmi naraz nie je nejasnosť", () => {
  const os = O.postav([r("1", "7", "0", "1", "A", "ŠKOLENIE", "08:00", "12:00", "0", ""), r("1", "7", "1", "2", "B", "ŠKOLENIE", "08:00", "12:00", "0", "")]);
  assert.equal(os.problemy.length, 0);
});

test("hradenie záložným vozidlom 944 nie je druhý vodič na službe", () => {
  const os = O.postav([
    r("1", "13", "0", "1", "Koller", "3/36", "05:28", "09:40", "0", "7905"),
    r("2", "2", "0", "2", "Hudek", "944/4", "04:00", "06:23", "0", "7521"),
    r("1", "13", "1", "2", "Hudek", "3/36", "06:23", "07:53", "0", "7521"),
    r("2", "2", "1", "2", "Hudek", "944/4", "07:53", "13:45", "0", "7521"),
  ]);
  assert.equal(os.problemy.length, 0);
});

test("koniec po polnoci sa berie zo skutočných časov úseku, nie z plánu turnusu", () => {
  const a = r("1", "1", "0", "1", "A", "1/1", "04:10", "13:37", "0", "7500", { NASTUP: cas("04:10"), KONEC: cas("00:21") });
  const b = r("1", "1", "1", "1", "A", "1/1", "13:37", "14:14", "0", "7500", { NASTUP: cas("13:37"), KONEC: cas("00:21") });
  const noc = r("1", "2", "0", "1", "A", "1/1", "22:00", "01:00", "0", "7500", { SKUTKONEC: cas("01:00", "2026-10-18") });
  const u = den(O.postav([a, b, noc]), "1").useky;
  assert.equal(u[1].doMin - u[1].odMin, 37); // 13:37–14:14, nie +24 h
  assert.equal(u[2].doMin - u[2].odMin, 180); // 22:00–01:00 cez polnoc
  assert.equal(u[2].poPolnoci, true);
});

test("koniec po polnoci aj so zlým dátumom konca v exporte", () => {
  const x = r("1", "3", "0", "1", "A", "944/5", "18:24", "01:00"); // SKUTKONEC má ten istý dátum
  const u = den(O.postav([x]), "1").useky[0];
  assert.equal(u.doMin - u.odMin, 396);
  assert.equal(u.zlyDatumKonca, true);
});

test("služba bez vozidla a neznámy kód neprítomnosti sa nahlásia", () => {
  const os = O.postav([r("1", "1", "0", "1", "A", "3/10", "08:00", "12:00", "0", ""), r("1", "2", "0", "2", "B", "3/10", "08:00", "12:00", "999", "")]);
  assert.equal(den(os, "1").problemy[0].druh, "bez_vozidla");
  assert.equal(den(os, "2").problemy[0].druh, "neznamy_kod_stavu");
});

test("os je zoradená podľa času a pozná druh úseku", () => {
  const os = O.postav([r("1", "2", "0", "1", "A", "pohotovosť E2", "13:00", "21:00", "0", ""), r("1", "1", "0", "1", "A", "3/10", "05:00", "12:00")]);
  const u = den(os, "1").useky;
  assert.equal(u[0].kurz, "3/10");
  assert.equal(u[1].druh, "pohotovost");
});

test("pomocné funkcie osi sú zhodné s adaptérom pre kurzy z exportu", () => {
  const a = nacitaj("js/data/cisti-riadky.js", "js/data/adapter-csv.js");
  const n = O.pomocne.normKurz;
  assert.equal(n("3/04", 1), "3/4");
  assert.equal(n("9/24str", 1), "9/24");
  assert.equal(n("3/41+3/19JME", 1), "3/41");
  assert.equal(n("3/41+3/19JME", 2), "3/19");
  assert.ok(a._csv2raw);
});

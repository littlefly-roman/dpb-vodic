import "../js/data/odpocinok.js";
const O = globalThis.DpbOdpocinok;
const h = (x) => x * 60, d = (n, hh = 0) => n * 1440 + hh * 60;
let f = 0; const t = (n, c) => { if (!c) { f++; console.log("CHYBA:", n); } else console.log("ok:", n); };
// bez inej práce: ok
t("prázdny kalendár", O.skontroluj([], { od: d(10, 6), do: d(10, 14) }).ok);
// odpočinok 12 h pred, 12 h po: ok bez skrátenia
let r = O.skontroluj([{ od: d(9, 6), do: d(9, 14) - h(0) - h(4) }, { od: d(11, 2), do: d(11, 10) }], { od: d(10, 6), do: d(10, 14) });
t("12h pred a po -> ok, nie skrátený", r.ok && !r.skrateny);
// 8 h pred -> skrátený
r = O.skontroluj([{ od: d(9, 6), do: d(9, 22) }], { od: d(10, 6), do: d(10, 12) });
t("8h pred -> skrátený", r.ok && r.skrateny && r.skrateny.pred === h(8));
// 5 h 59 min pred -> nie
r = O.skontroluj([{ od: d(9, 6), do: d(10, 0) }], { od: d(10, 5, 0) + 59, do: d(10, 12) });
t("5:59 pred -> nie", !r.ok);
// presne 6 h -> skrátený ok
r = O.skontroluj([{ od: d(9, 6), do: d(10, 0) }], { od: d(10, 6), do: d(10, 12) });
t("presne 6h -> ok skrátený", r.ok && r.skrateny);
// 7 dní práce po sebe (každý deň 6–14) + kandidát 8. deň -> nie (nikde 35 h)
let pr = []; for (let i = 0; i < 7; i++) pr.push({ od: d(i, 6), do: d(i, 14) });
r = O.skontroluj(pr, { od: d(7, 6), do: d(7, 14) });
t("8. deň po sebe bez 35h voľna -> nie", !r.ok);
// 6 dní práce + kandidát 7. deň: v okne 168 h od 0:00 d0 do d7 0:00 je len deň 6 voľný... 
pr = []; for (let i = 0; i < 6; i++) pr.push({ od: d(i, 6), do: d(i, 14) });
r = O.skontroluj(pr, { od: d(6, 6), do: d(6, 14) });
t("7 dní po sebe -> nie (okno bez 35h)", !r.ok);
// 5 dní práce, potom 2 voľné, potom kandidát: ok
pr = []; for (let i = 0; i < 5; i++) pr.push({ od: d(i, 6), do: d(i, 14) });
r = O.skontroluj(pr, { od: d(7, 6), do: d(7, 14) });
t("5 dní + 2 voľné + kandidát -> ok", r.ok);
// presná hranica 35 h: týždenný cyklus 133 h práce (nepretržite) + 35 h voľna
const W = 10080; let cyk = []; for (let k = 0; k < 4; k++) cyk.push({ od: k * W + 2100, do: (k + 1) * W });
r = O.skontroluj(cyk, { od: 4 * W + 2100, do: 5 * W });
t("cyklus s voľnom presne 35h -> ok", r.ok);
r = O.skontroluj(cyk, { od: 4 * W + 2099, do: 5 * W });
t("voľno 34:59 -> nie", !r.ok);
console.log(f ? "NEPREŠLO " + f : "VŠETKO OK");
process.exit(f ? 1 : 0);

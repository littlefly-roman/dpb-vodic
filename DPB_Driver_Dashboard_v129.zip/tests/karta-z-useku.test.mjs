import test from "node:test";
import assert from "node:assert/strict";
import { nacitaj } from "./pomocnik.mjs";

const w = nacitaj("js/data/cisti-riadky.js", "js/data/ciselnik-stavov.js", "js/data/os-vodica.js", "js/data/karta-z-useku.js");
const O = w.DpbOsVodica, K = w.DpbKartaZUseku;
const D = "2026-10-17";
const cas = (hm, den = D) => `${den} ${hm}:00.000`;
const r = (rad, kurz, od, do_, voz = "7500", extra = {}) => ({
  CISLO_VYPRAVENKY: "1", CISLOTURNUSU: "E1", RADEK: rad, PORADI: "0", DATUM: D, RIDIC_CISLO: "5", RIDIC_PRIJMENI: "Test", RIDIC_JMENO: "",
  LINKAKURZ: kurz, TRIDENI: "1", NASTUP: cas(od), KONEC: cas(do_), SKUTNASTUP: cas(od), SKUTKONEC: cas(do_), STAVTURNUSU: "0", CISVOZU1: voz, ...extra,
});
const karta = (row, vzor) => Object.assign(K.sluzbaZaklad(O.usek(row), vzor), { pred: null, nasl: null });

test("pohotovosti jedného dňa sa zlúčia: od = najskorší začiatok, do = najneskorší koniec, aj cez polnoc", () => {
  const a = karta(r("1", "pohotovosť E2", "13:00", "17:00", ""), "POHOTOVOSŤ");
  const b = karta(r("2", "pohotovosť E2", "20:00", "05:30", "", { SKUTKONEC: cas("05:30", "2026-10-18") }), "POHOTOVOSŤ");
  const out = K.zlucPohotovosti([a, b]);
  assert.equal(out.length, 1);
  assert.equal(out[0].od, "13:00");
  assert.equal(out[0].do, "05:30");
  assert.equal(out[0].do_min, 5 * 60 + 30 + 1440);
});

test("úsek služby počas pohotovosti sa vnorí, ak pohotovosť pred ním aj po ňom pokračuje", () => {
  const p1 = r("1", "pohotovosť E1", "13:00", "14:14", "");
  const s = r("2", "1/1", "14:14", "14:36");
  const p2 = r("3", "pohotovosť E1", "14:36", "21:00", "");
  const poh = karta(p1, "POHOTOVOSŤ"), poh2 = karta(p2, "POHOTOVOSŤ");
  const slu = karta(s, "SLUŽBA");
  const spojena = K.zlucPohotovosti([poh, slu, poh2]);
  const out = K.vnorDoPohotovosti(spojena, [O.usek(p1), O.usek(p2)]);
  assert.equal(out.length, 1);
  assert.equal(out[0].segmenty.length, 1);
  assert.equal(out[0].segmenty[0].kurz, "1/1");
});

test("služba mimo pohotovosti sa nevnorí", () => {
  const p1 = r("1", "pohotovosť E1", "13:00", "14:00", "");
  const poh = karta(p1, "POHOTOVOSŤ");
  const slu = karta(r("2", "1/1", "15:00", "16:00"), "SLUŽBA");
  const out = K.vnorDoPohotovosti([poh, slu], [O.usek(p1)]);
  assert.equal(out.length, 2);
});

test("944: nadväzujúce úseky sú jedna karta, ostatné kurzy sú hradenia, minúty idú cez polnoc", () => {
  const rows = [
    r("1", "944/05", "14:30", "16:24", "7001"),
    r("2", "4/16", "16:24", "18:24", "7002"),
    r("3", "944/05", "18:24", "01:00", "7003", { SKUTKONEC: cas("01:00") }), // zlý dátum konca
  ];
  const res = K.zasuvka944(rows.map(O.usek), () => ({ pred: null, nasl: null }), O.pomocne.normKurz);
  assert.equal(res.karty.length, 1);
  const k = res.karty[0];
  assert.equal(k.kurz, "944/5");
  assert.equal(k.hradenia.length, 1);
  assert.equal(k.hradenia[0].kurz, "4/16");
  assert.equal(k.od, "14:30");
  assert.equal(k.do, "01:00");
  assert.equal(k.do_min - k.od_min, 630);
  assert.equal(res.zostatok.length, 0);
});

test("944: úsek, ktorý nenadväzuje na reťaz s 944, zostane na obyčajnú kartu", () => {
  const rows = [r("1", "944/05", "14:30", "16:00"), r("2", "3/10", "18:00", "20:00")];
  const res = K.zasuvka944(rows.map(O.usek), () => ({ pred: null, nasl: null }), O.pomocne.normKurz);
  assert.equal(res.karty.length, 1);
  assert.equal(res.zostatok.length, 1);
  assert.equal(res.zostatok[0].kurz, "3/10");
});

const dnes = (riadky) => K.indexDna({ [D]: riadky }, O.usek);
const meno = { 1: "Prvý", 2: "Druhý", 3: "Tretí", 5: "Test" };

test("predchodca: iný vodič končí na rovnakom kurze v čase môjho nástupu; nasledovník: nastupuje v čase môjho konca", () => {
  const pred = r("1", "3/10", "05:00", "09:00", "7500", { RIDIC_CISLO: "1" });
  const ja = r("1", "3/10", "09:00", "13:00", "7500", { RIDIC_CISLO: "2", PORADI: "1" });
  const nasl = r("1", "3/10", "13:00", "17:00", "7500", { RIDIC_CISLO: "3", PORADI: "2" });
  const idx = dnes([pred, ja, nasl]);
  const pn = K.predNasl(O.usek(ja), idx, meno);
  assert.equal(pn.pred.meno, "Prvý");
  assert.equal(pn.pred.cas, "09:00");
  assert.equal(pn.nasl.meno, "Tretí");
});

test("nasledovník sa neukazuje, ak služba končí v depe", () => {
  const ja = r("1", "3/10", "09:00", "13:00", "7500", { RIDIC_CISLO: "2", STANSMERPRIJEZD: "Dp. Krasňany" });
  const nasl = r("1", "3/10", "13:00", "17:00", "7500", { RIDIC_CISLO: "3", PORADI: "1" });
  const pn = K.predNasl(O.usek(ja), dnes([ja, nasl]), meno);
  assert.equal(pn.nasl, null);
});

test("sám seba nikdy nemám za predchodcu ani nasledovníka", () => {
  const a = r("1", "3/10", "05:00", "09:00");
  const b = r("1", "3/10", "09:00", "13:00", "7500", { PORADI: "1" });
  const pn = K.predNasl(O.usek(b), dnes([a, b]), meno);
  assert.equal(pn.pred, null);
});

test("výpravca: denná KR má predchodcu v nočnej KR predchádzajúceho dňa", () => {
  const den = r("1", "dennáKR", "05:00", "17:00", "", { RIDIC_CISLO: "2" });
  const nocPred = r("2", "nočnáKR", "17:00", "05:00", "", { RIDIC_CISLO: "1", DATUM: "2026-10-16" });
  const nocDnes = r("3", "nočnáKR", "17:00", "05:00", "", { RIDIC_CISLO: "3" });
  const idx = K.indexDna({ "2026-10-16": [nocPred], [D]: [den, nocDnes] }, O.usek);
  const pn = K.predNaslVypravca(O.usek(den), idx, meno);
  assert.equal(pn.pred.meno, "Prvý");
  assert.equal(pn.nasl.meno, "Tretí");
});

test("prestávky: striedač sa nájde v indexe, vlastný vodič sa preskočí, mimo času nie je meno", () => {
  const karta = (vzor, kurz, od, do_) => ({ vzor, kurz, od_min: od, do_min: do_ });
  const models = {
    "1": [{ datum: D, karty: [karta("SLUŽBA", "3/19", 360, 840)] }],
    "2": [{ datum: D, karty: [karta("SLUŽBA", "3/43", 360, 700)] }],
    "3": [{ datum: D, karty: [karta("STRIEDAČ", "3/43", 700, 900)] }],
  };
  const str = { "3/43|1": [{ z: "Krížna", k: [{ kurz: "3/19", prebera: "7:00", odovzdava: "7:30" }, { kurz: "3/19", prebera: "13:30", odovzdava: "14:00" }] }] };
  K.pridajPrestavky(models, { "2": "Anna", "3": "Boris" }, str, () => 1, (t) => { const p = t.split(":"); return +p[0] * 60 + +p[1]; });
  const pr = models["1"][0].karty[0]["prestávka"];
  assert.equal(pr.length, 2);
  assert.equal(pr[0].str_meno, "Anna");
  assert.equal(pr[1].str_meno, "Boris");
  assert.equal(pr[0].zastávka, "Krížna");
});
